﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.IO;

namespace GoodBreaksClasses
{
    class BlobStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        internal CloudBlobClient _blobClient;        

        //Constructor
        public BlobStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _blobClient = _storageAccount.CreateCloudBlobClient();
        }

        public void CreateBlobContainer(string name)
        {
            var container = _blobClient.GetContainerReference("profilepics");
            container.CreateIfNotExist();
        }

        public void SaveProfilePic(string surferCompleteKey)
        {
            var container = _blobClient.GetContainerReference("profilepics");
            var blob = container.GetBlobReference(surferCompleteKey);

            
        }
    }
}
