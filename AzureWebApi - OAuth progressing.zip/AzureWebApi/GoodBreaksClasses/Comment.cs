﻿using System;
using System.Globalization;
using System.Data.Services.Common;

namespace GoodBreaksClasses
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Comment
    {

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string AboutKey { get; set; }
        public string FromSurferKey { get; set; }
        public string CommentText { get; set; }
        public Surfer FromSurfer { get; set; }
        public ICommentable About { get; set; }
        public DateTime CommentDateTime { get; set; }

        //constructors
        public Comment()
        { }

        public Comment(string text, Surfer fromSurfer, ICommentable commentAbout)
        {
            CommentText = text;
            CommentDateTime = DateTime.UtcNow;
            FromSurfer = fromSurfer;
            FromSurfer.CommentsByMe.Add(this);
            About = commentAbout;
            commentAbout.AddComment(this);
            AboutKey = KeyBuilder.BuildAboutKey(this, About);
            FromSurferKey = KeyBuilder.BuildFromKey(fromSurfer);
            PartitionKey = FromSurfer.PartitionKey;
            RowKey = "com-" + Guid.NewGuid().ToString();
        }
    }
}
