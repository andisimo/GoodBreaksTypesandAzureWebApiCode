﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using OAuth2.Mvc;

namespace GoodBreaksClasses
{
    class SecurityStorageHelper: TableServiceEntity
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "Creds";

        //public properties
        public string HashSalt { get; set; }
        public string HashedPassword { get; set; }

        //constructors
        public SecurityStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                   (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //methods
        public Dictionary<string, string> Retrieve(string relatedObjectCompleteKey)
        {
            var securityKeys = TableStorageHelper.ParseCompleteKey(relatedObjectCompleteKey);

            SecurityStorageHelper securityInfo=
                (from getThis in _serviceContext.CreateQuery<SecurityStorageHelper>(_tableName)
                 where getThis.PartitionKey == securityKeys["region"] &&
                 getThis.RowKey == securityKeys["id"]
                 select getThis).FirstOrDefault();

            var creds = new Dictionary<string, string>();
            creds.Add("userSalt", securityInfo.HashSalt);

            return creds;
        }

        public string Save(string newSurferPK, string newSurferRK, string newSurferPassword)
        {
            PartitionKey = newSurferPK;
            RowKey = newSurferRK;
            HashSalt = Guid.NewGuid().ToString("N");
            HashedPassword = (HashSalt + newSurferPassword).ToSHA1();
            
            _serviceContext.AddObject(_tableName, this);

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();

            return HashSalt;
        }

        public void Delete()
        {
            _serviceContext.AttachTo(_tableName, this, "*");
            _serviceContext.DeleteObject(this);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
