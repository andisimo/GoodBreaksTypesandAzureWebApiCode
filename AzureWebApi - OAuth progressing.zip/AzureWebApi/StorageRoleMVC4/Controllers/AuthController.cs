﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using OAuth2.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace StorageRoleMVC4.Controllers
{
    public class AuthController : ApiController
    {
        //Get a RequestToken
        public string Get()
        {
            var requestToken = OAuthServiceBase.Instance.RequestToken();

            return JsonConvert.SerializeObject(requestToken);
        }
        
        public HttpResponseMessage Post([FromBody] Surfer surfer, [FromUri] string password)
        {
            string hashSalt = string.Empty;
            var helper = new SurferStorageHelper();
            hashSalt = helper.Save(surfer, password);

            var response = Request.CreateResponse(HttpStatusCode.OK, hashSalt);
            return response;
        }
    }
}
