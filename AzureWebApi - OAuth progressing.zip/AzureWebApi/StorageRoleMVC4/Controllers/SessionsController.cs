﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class SessionsController : ApiController
    {
        public Session Get([FromUri] string sessionPK, string sessionRK)
        {
            var helper = new SessionStorageHelper();
            var session = helper.Retrieve(sessionPK, sessionRK);

            return session;
        }

        public HttpResponseMessage Post([FromBody] Session session)
        {
            var helper = new SessionStorageHelper();
            helper.Save(session);

            var response = Request.CreateResponse<Session>(HttpStatusCode.OK, session);
            return response;
        }

        public HttpResponseMessage Put([FromBody] Session session)
        {
            var helper = new SessionStorageHelper();
            helper.Upsert(session);

            var response = Request.CreateResponse<Session>(HttpStatusCode.OK, session);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Session session)
        {
            var helper = new SessionStorageHelper();
            helper.Delete(session);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
