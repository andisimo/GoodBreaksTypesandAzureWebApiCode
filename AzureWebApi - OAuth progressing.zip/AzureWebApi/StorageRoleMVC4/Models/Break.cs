﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Services.Common;

namespace GoodBreaksWP7.Models
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Break : ICommentable, INotifyPropertyChanged
    {
        //fields
        private SortedCommentList _commentsAboutMe = new SortedCommentList();
        private ICollection<Surfer> _thereNow = new ObservableCollection<Surfer>();

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string Name { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Region { get; set; }

        public SortedCommentList CommentsAboutMe
        {
            get { return _commentsAboutMe; }
            set 
            {
                if (_commentsAboutMe != value)
                {
                    _commentsAboutMe = value;
                    NotifyPropertyChanged("CommentsAboutMe");
                }
            }
        }

        public ICollection<Surfer> ThereNow
        {
            get { return _thereNow; }
            set
            {
                if (_thereNow != value)
                {
                    _thereNow = value;
                    NotifyPropertyChanged("ThereNow");
                }
            }
        }

        //Constructors
        public Break(string breakName, double locLatitude, double locLongitude)
        {
            Name = breakName;
            Latitude = locLatitude;
            Longitude = locLongitude;
        }

        //Methods
        public void AddComment(Comment comment)
        {
            CommentsAboutMe.Add(comment);
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            var handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
