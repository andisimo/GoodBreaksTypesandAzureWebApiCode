﻿using System;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Reflection;
using Newtonsoft.Json;

namespace GoodBreaksClasses
{
    public class CommentStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SurfersComments";

        //Constructor
        public CommentStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Comment Retrieve(string partitionKey, string rowKey)
        {
            Comment comment =
                (from getThis in _serviceContext.CreateQuery<Comment>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return comment;
        }

        public void Save(Comment commentToSave)
        {
            if (commentToSave.About == null)
            {
                throw new InvalidOperationException(@"An error occurred when trying to save the comment. 
                    The comment's 'About' property cannot be null");
            }

            //for some reason, if the Comment.About property has a value,
            //we get an InvalidInput error from table storage. Since we
            //don't save this value, we'll just strip it off here.
            dynamic aboutObject = commentToSave.About;
            commentToSave.About = null;

            _serviceContext.AddObject(_tableName, commentToSave);
            _serviceContext.IgnoreMissingProperties = true;

            _serviceContext.SaveChanges();

            AddToCommentsAboutMe(aboutObject: aboutObject, comment: commentToSave);
            AddToCommentsByMe(surfer: commentToSave.FromSurfer, comment: commentToSave);
        }

        public void AddToCommentsAboutMe(dynamic aboutObject, Comment comment)
        {
            var helper = new CommentsAboutMeStorageHelper(
                TableStorageHelper.ConstructCompleteKey(aboutObject.PartitionKey, aboutObject.RowKey), 
                TableStorageHelper.ConstructCompleteKey(comment.PartitionKey, comment.RowKey));

            helper.Upsert();
        }

        public void AddToCommentsByMe(Surfer surfer, Comment comment)
        {
            var helper = new CommentsByMeStorageHelper(
                TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey), 
                TableStorageHelper.ConstructCompleteKey(comment.PartitionKey, comment.RowKey));

            helper.Upsert();
        }

        public void Upsert(Comment commentToSave)
        {
            if (commentToSave.About == null)
            {
                throw new InvalidOperationException(@"An error occurred when trying to save the comment. 
                    The comment's 'About' property cannot be null");
            }

            //for some reason, if the Comment.About property has a value,
            //we get an InvalidInput error from table storage. Since we
            //don't save this value, we'll just strip it off here.
            dynamic aboutObject = commentToSave.About;
            commentToSave.About = null;

            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, commentToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(commentToSave);
                _serviceContext.AttachTo(_tableName, commentToSave, null);
            }

            _serviceContext.UpdateObject(commentToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();

            AddToCommentsAboutMe(aboutObject: aboutObject, comment: commentToSave);
            AddToCommentsByMe(surfer: commentToSave.FromSurfer, comment: commentToSave);
        }

        public void Delete(Comment commentToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, commentToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(commentToDelete);
                _serviceContext.AttachTo(_tableName, commentToDelete, "*"); 
            }

            _serviceContext.DeleteObject(commentToDelete);
            _serviceContext.SaveChanges();
        }

        private void DeleteAllTraces(Comment deletedComment)
        {
            string commentCompleteKey = TableStorageHelper.ConstructCompleteKey(
                deletedComment.PartitionKey, deletedComment.RowKey);

            //Delete Rows in CommentsAboutMe
            //Put something in an Azure queue to have a worker role delete these

            //Delete Rows in CommentsByMe
            //Put something in an Azure queue to have a worker role delete these
        }
    }
}
