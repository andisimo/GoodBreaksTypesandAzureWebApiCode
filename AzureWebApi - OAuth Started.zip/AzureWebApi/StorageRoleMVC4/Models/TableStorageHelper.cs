﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.Data.Services.Client;
using GoodBreaksWP7;
using GoodBreaksWP7.Models;
using System.Reflection;
using System.Xml.Linq;
using Evaluant.Linq.Compiler;

namespace StorageRoleMVC4.Models
{
    internal class TableStorageHelper<T> 
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        internal CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;

        //private members
        private string _tableName = "";
        private int _highestIndex;
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //Constructor
        internal TableStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionString"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext(); 
        }

        //Methods
        internal void Save(string tableName, dynamic itemToSave)
        {
            _tableName = tableName;
            _serviceContext.AddObject(tableName, itemToSave); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        internal void UpdateUntrackedEntity(string tableName, dynamic itemToSave)
        {
            _serviceContext.AttachTo(tableName, itemToSave, "*");

            _serviceContext.UpdateObject(itemToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        internal void Update(string tableName, dynamic itemToSave)
        {
            _serviceContext.UpdateObject(itemToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        internal void UpdateCommentsAbout(dynamic itemToSave)
        {
            _serviceContext.ReadingEntity += new EventHandler<ReadingWritingEntityEventArgs>(_serviceContext_ReadingEntity);
            _serviceContext.WritingEntity += new EventHandler<ReadingWritingEntityEventArgs>(_serviceContext_WritingEntity);

            LinqCompiler lc = new LinqCompiler(@"(from obj in source
                where obj.PartitionKey == @param1 && obj.RowKey == @param2 
                select obj).FirstOrDefault()"); 
            lc.Values.Add("param1", itemToSave.PartitionKey);
            lc.Values.Add("param2", itemToSave.RowKey); 
            lc.ExternalAssemblies.Add(typeof(System.Xml.Linq.XDocument).Assembly);
            lc.ExternalAssemblies.Add(typeof(System.Xml.IXmlLineInfo).Assembly);
            lc.AddSource("source", _serviceContext.CreateQuery<T>(_tableName));
            var objectToCountProps = lc.Evaluate();
            
            
            
            //var objectToCountProps =
            //    (from dynamic obj in _serviceContext.CreateQuery<T>(_tableName)
            //     where obj.PartitionKey == itemToSave.PartitionKey && obj.RowKey == itemToSave.RowKey
            //     select obj).FirstOrDefault();
            
            Update(_tableName, objectToCountProps);
        }

        private void _serviceContext_ReadingEntity(object sender, ReadingWritingEntityEventArgs e)
        {
            var propertyNode = e.Data.Descendants(_m + "properties").First();
            var properties = propertyNode.DescendantNodes();
            foreach (XNode node in properties)
            {
                XElement element = node as XElement;
                if (element != null)
                {
                    string name = element.Name.ToString();

                    if (name.Contains("CommentsAboutMe"))
                    {
                        int int1 = name.IndexOf("CommentsAboutMe");
                        string string1 = name.Substring(int1 + 15);
                        int index = Int32.Parse(string1);
                        if (index > _highestIndex)
                            _highestIndex = index;
                    }
                }
            }
        }

        private void _serviceContext_WritingEntity(object sender, ReadingWritingEntityEventArgs e)
        {
            XElement properties;
            Surfer surfer = e.Entity as Surfer;

            if (surfer != null)
            {
                List<Comment> commentsAbout = surfer.CommentsAboutMe.Comments.ToList<Comment>();
                foreach (Comment c in commentsAbout)
                {
                    _highestIndex++;
                    XElement propertyToAdd = new XElement(_d + "CommentsAboutMe" + _highestIndex.ToString(), c.CommentText);
                    properties = e.Data.Descendants(_m + "properties").First();
                    properties.Add(propertyToAdd);
                }
            }
        }

        public void UpdateCommentsFrom()
        {
            throw new NotImplementedException();
        }
    }
}