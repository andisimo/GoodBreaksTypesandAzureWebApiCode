﻿using System;

namespace GoodBreaksWP7.Models
{
    public class SurfBoard
    {
        //fields
        private Guid _id;

        //properties
        public Guid Id
        {
            get { return _id; }
        }

        public string BoardName { get; set; }

        //constructors
        public SurfBoard(string name)
        {
            _id = Guid.NewGuid();
            BoardName = name;
        }
    }
}
