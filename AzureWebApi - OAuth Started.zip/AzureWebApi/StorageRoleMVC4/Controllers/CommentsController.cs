﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class CommentsController : ApiController
    {
        public Comment GET([FromUri]string commentPK, string commentRK)
        {
            var helper = new CommentStorageHelper();
            var comment = helper.Retrieve(partitionKey: commentPK, rowKey: commentRK);

            return comment;
        }

        public HttpResponseMessage Post([FromBody]Comment comment)
        {
            var helper = new CommentStorageHelper();
            helper.Save(comment);

            var response = Request.CreateResponse<Comment>(HttpStatusCode.Created, comment);
            return response;
        }

        public HttpResponseMessage Post(string commentText, string fromSurferCompleteKey, string aboutCompleteKey)
        {
            var tableHelper = new TableStorageHelper();
            var commentHelper = new CommentStorageHelper();
            var surferHelper = new SurferStorageHelper();

            var fromSurferKeys = TableStorageHelper.ParseCompleteKey(fromSurferCompleteKey);
            var fromSurfer = surferHelper.Retrieve(fromSurferKeys["region"], fromSurferKeys["id"]);

            var aboutObjectKeys = TableStorageHelper.ParseCompleteKey(aboutCompleteKey);
            var aboutObject = tableHelper.Retrieve(aboutObjectKeys["type"], aboutObjectKeys["region"], aboutObjectKeys["id"]);

            var comment = new Comment(commentText, fromSurfer, aboutObject);
            commentHelper.Save(comment);

            var response = Request.CreateResponse<Comment>(HttpStatusCode.Created, comment);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Comment comment)
        {
            var helper = new CommentStorageHelper();
            helper.Delete(comment);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
