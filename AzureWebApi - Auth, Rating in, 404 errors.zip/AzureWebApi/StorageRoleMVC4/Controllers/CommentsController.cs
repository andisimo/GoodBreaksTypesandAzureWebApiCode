﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace StorageRoleMVC4.Controllers
{
    public class CommentsController : ApiController
    {
        public Comment GET([FromUri]string commentPK, string commentRK)
        {
            var helper = new CommentStorageHelper();
            var comment = helper.Retrieve(partitionKey: commentPK, rowKey: commentRK);

            return comment;
        }

        public HttpResponseMessage Post([FromBody] JRaw comment)
        {
            var parsedComment = new Comment();

            JObject json = JObject.Parse(comment.ToString());

            parsedComment.AboutKey = (string)json["AboutKey"];

            var tableHelper = new TableStorageHelper();
            var aboutObjectKeys = TableStorageHelper.ParseCompleteKey(parsedComment.AboutKey);
            parsedComment.About = tableHelper.Retrieve(aboutObjectKeys["type"], 
                aboutObjectKeys["region"], aboutObjectKeys["id"]);
            
            parsedComment.CommentText = (string)json["CommentText"];
            parsedComment.FromSurferKey = (string)json["FromSurferKey"];
            parsedComment.PartitionKey = (string)json["PartitionKey"];

            if ((object)json["rating"] != null) 
            { 
                parsedComment.Rating = (int)json["Rating"]; 
            }

            parsedComment.RowKey = (string)json["RowKey"];

            var helper = new CommentStorageHelper();
            helper.Save(parsedComment);

            var response = Request.CreateResponse<Comment>(HttpStatusCode.Created, parsedComment);
            return response;
        }

        public HttpResponseMessage Post(string commentText, string fromSurferCompleteKey, string aboutCompleteKey)
        {
            var tableHelper = new TableStorageHelper();
            var commentHelper = new CommentStorageHelper();
            var surferHelper = new SurferStorageHelper();

            var fromSurferKeys = TableStorageHelper.ParseCompleteKey(fromSurferCompleteKey);
            var fromSurfer = surferHelper.Retrieve(fromSurferKeys["region"], fromSurferKeys["id"]);

            var aboutObjectKeys = TableStorageHelper.ParseCompleteKey(aboutCompleteKey);
            var aboutObject = tableHelper.Retrieve(aboutObjectKeys["type"], aboutObjectKeys["region"], aboutObjectKeys["id"]);

            var comment = new Comment(commentText, fromSurfer, aboutObject);
            commentHelper.Save(comment);

            var response = Request.CreateResponse<Comment>(HttpStatusCode.Created, comment);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Comment comment)
        {
            var helper = new CommentStorageHelper();
            helper.Delete(comment);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
