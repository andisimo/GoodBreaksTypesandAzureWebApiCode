﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class SurfersController : ApiController
    {
        public Surfer Get([FromUri]string surferPK, string surferRK)
        {
            var helper = new SurferStorageHelper();
            var surfer = helper.Retrieve(partitionKey: surferPK, rowKey: surferRK);

            return surfer;
        }

        public HttpResponseMessage Put([FromBody] Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Update(surfer);

            var response = Request.CreateResponse(HttpStatusCode.OK, surfer);
            return response;
        }

        //Create a new user, store and hash password, return hash salt
        public HttpResponseMessage Post([FromBody] Surfer surfer, [FromUri] string password)
        {
            if (surfer.Region == null || surfer.Region == "" || surfer.PartitionKey == null || surfer.PartitionKey == "" 
                || surfer.RowKey == null || surfer.RowKey == "")
            {
                throw new HttpRequestException(@"You can't create a surfer with a NULL Region, PartitionKey, or RowKey
                    You should use the non-default constructor to create the Surfer object you pass to this API method."); 
            }

            var surferHelper = new SurferStorageHelper();
            string hashSalt = surferHelper.Save(surfer, password);

            var response = Request.CreateResponse(HttpStatusCode.OK, hashSalt);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Delete(surfer);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
