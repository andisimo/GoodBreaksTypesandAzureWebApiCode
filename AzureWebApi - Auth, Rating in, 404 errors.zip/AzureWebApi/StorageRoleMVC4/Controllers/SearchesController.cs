﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;

namespace StorageRoleMVC4.Controllers
{
    public class SearchesController : ApiController
    {
        public Dictionary<string, string> Get([FromUri] string searchString, [FromUri] string searchObject)
        {
            var searchHelper = new SearchStorageHelper();
            var objectList = searchHelper.Retrieve(searchString, searchObject);

            return objectList;
        }

        public string get()
        {
            return "hi there.";
        }
    }
}

