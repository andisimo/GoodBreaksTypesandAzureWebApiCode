﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using System.Net.Http;
using System.Net;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfBreaksController : ApiController
    {
        public List<Break> Get(string relatedObjectPK, string relatedObjectRK)
        {
            var helper = new BreakCollectionStorageHelper();
            var breakList = helper.RetrieveBreaks(
                TableStorageHelper.ConstructCompleteKey(relatedObjectPK, relatedObjectRK));

            return breakList;
        }

        public HttpResponseMessage Post(string relatedObjectPK, string relatedObjectRK, string breakPK, string breakRK)
        {
            var helper = new BreakCollectionStorageHelper();
            
            helper.PartitionKey = TableStorageHelper.ConstructCompleteKey(
                relatedObjectPK, relatedObjectRK);

            helper.RowKey = TableStorageHelper.ConstructCompleteKey(
                breakPK, breakRK);

            helper.Upsert();
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        public HttpResponseMessage Delete(string relatedObjectPK, string relatedObjectRK, string breakPK, string breakRK)
        {
            var helper = new BreakCollectionStorageHelper();

            helper.PartitionKey = TableStorageHelper.ConstructCompleteKey(
                relatedObjectPK, relatedObjectRK);

            helper.RowKey = TableStorageHelper.ConstructCompleteKey(
                breakPK, breakRK);

            helper.Delete();
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}