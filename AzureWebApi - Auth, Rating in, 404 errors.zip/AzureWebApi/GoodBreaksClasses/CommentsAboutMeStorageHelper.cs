﻿using System;
using System.Collections.Generic;
using System.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class CommentsAboutMeStorageHelper : TableServiceEntity, ICollectionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "CommentsAboutMe";

        //constructors
        public CommentsAboutMeStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                   (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        public CommentsAboutMeStorageHelper(string aboutObjectCompleteKey, string commentCompleteKey)
        {
            _storageAccount = CloudStorageAccount.Parse
               (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();

            PartitionKey = aboutObjectCompleteKey;
            RowKey = commentCompleteKey;
        }

        //methods
        public List<Comment> RetrieveComments(string aboutObjectCompleteKey)
        {
            CloudTableQuery<CommentsAboutMeStorageHelper> partitionQuery =
                (from e in _serviceContext.CreateQuery<CommentsAboutMeStorageHelper>(_tableName)
                 where e.PartitionKey == aboutObjectCompleteKey
                 select e).AsTableServiceQuery<CommentsAboutMeStorageHelper>();

            var commentIdList = new List<string>();
            foreach (CommentsAboutMeStorageHelper c in partitionQuery)
            {
                string id = c.RowKey;
                commentIdList.Add(id);
            }

            var commentHelper = new CommentStorageHelper();
            var commentList = new List<Comment>();
            foreach (string s in commentIdList)
            {
                var completeKey = TableStorageHelper.ParseCompleteKey(s);
                var comment = commentHelper.Retrieve(completeKey["region"], completeKey["id"]);
                commentList.Add(comment);
            }

            return commentList;
        }

        public void Upsert()
        {
            //null e-tag - upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, this, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(this);
                _serviceContext.AttachTo(_tableName, this, null);
            }

            if (this.PartitionKey != null && this.RowKey != null)
            {
                _serviceContext.UpdateObject(this);
            }
            else
            {
                throw new InvalidOperationException("The current instance of" +
                    "BreakThereNowStorageHelper has a NULL value for either the PartitionKey" +
                    "propert, the RowKey property, or both.");
            }

            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete()
        {
            try
            {
                _serviceContext.AttachTo(_tableName, this, "*");
            }
            catch
            {
                _serviceContext.Detach(this);
                _serviceContext.AttachTo(_tableName, this, "*");
            }

            _serviceContext.DeleteObject(this);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
