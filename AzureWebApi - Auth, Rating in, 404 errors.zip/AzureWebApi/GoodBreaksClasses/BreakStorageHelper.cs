﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class BreakStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SessionsBreaks";

        //Constructor
        public BreakStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Break Retrieve(string partitionKey, string rowKey)
        {
            Break break1=
                (from getThis in _serviceContext.CreateQuery<Break>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return break1;
        }

        public List<Break> RetrieveBreaksInPartition(string partitionKey)
        {
            CloudTableQuery<Break> partitionQuery =
                (from e in _serviceContext.CreateQuery<Break>(_tableName)
                 where e.PartitionKey == partitionKey
                 select e).AsTableServiceQuery<Break>();

            var breakList = new List<Break>();
            foreach (Break b in partitionQuery)
            {
                if(b.RowKey.StartsWith("bre"))
                    breakList.Add(b);
            }

            return breakList;
        }

        public void Save(Break break1)
        {
            _serviceContext.AddObject(_tableName, break1); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();

            var searchHelper = new SearchStorageHelper();
            searchHelper.Save(break1);
        }

        public void Upsert(Break breakToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, breakToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(breakToSave);
                _serviceContext.AttachTo(_tableName, breakToSave, null);
            }

            _serviceContext.UpdateObject(breakToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();

            try
            {
                var searchHelper = new SearchStorageHelper();
                searchHelper.Save(breakToSave);
            }
            catch (DataServiceClientException)
            {
            }
            catch (DataServiceRequestException)
            {
            }
        }

        public void Update(Break breakToSave)
        {
            _serviceContext.UpdateObject(breakToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Delete(Break breakToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, breakToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(breakToDelete);
                _serviceContext.AttachTo(_tableName, breakToDelete, "*");
            }
            _serviceContext.DeleteObject(breakToDelete);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
