﻿using System;
using System.Data.Services.Client;
using System.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SurferStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SurfersComments";

        //Constructor
        public SurferStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Surfer Retrieve(string partitionKey, string rowKey)
        {
            Surfer surfer =
                (from getThis in _serviceContext.CreateQuery<Surfer>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return surfer;
        }

        public string Save(Surfer surfer, string password)
        {
            string hashSalt = string.Empty;
            _serviceContext.AddObject(_tableName, surfer); 
            _serviceContext.IgnoreMissingProperties = true;

            var securityHelper = new SecurityStorageHelper();
            try
            {                
                hashSalt = securityHelper.Save(surfer.PartitionKey, surfer.RowKey, password);

                _serviceContext.SaveChanges();
            }
            catch (Exception ex)
            {
                securityHelper.PartitionKey = surfer.PartitionKey;
                securityHelper.RowKey = surfer.RowKey;
                securityHelper.Delete();

                throw ex;
            }

            var searchHelper = new SearchStorageHelper();
            searchHelper.Save(surfer);

            return hashSalt;
        }

        public void Update(Surfer surfer)
        {
            _serviceContext.UpdateObject(surfer);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Surfer surferToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToSave);
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }

            _serviceContext.UpdateObject(surferToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();

            try
            {
                var searchHelper = new SearchStorageHelper();
                searchHelper.Save(surferToSave);
            }
            catch (DataServiceClientException)
            {
            }
            catch (DataServiceRequestException)
            {
            }
        }

        public void Delete(Surfer surferToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToDelete);
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }

            _serviceContext.DeleteObject(surferToDelete);
            _serviceContext.SaveChangesWithRetries();

            DeleteAllTraces(surferToDelete);
        }

        private void DeleteAllTraces(Surfer deletedSurfer)
        {
            string surferCompleteKey = TableStorageHelper.ConstructCompleteKey(
                deletedSurfer.PartitionKey, deletedSurfer.RowKey);
         
            //Delete his breaks from collection table
            var breakCollectionHelper = new BreakCollectionStorageHelper();
            var breakList = breakCollectionHelper.RetrieveBreaks(surferCompleteKey);

            foreach (Break b in breakList)
            {
                var breakCollectionDeleter = new BreakCollectionStorageHelper(surferCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(b.PartitionKey, b.RowKey));
                
                breakCollectionDeleter.Delete();
            }

            //Delete his buddies from buddy table
            var buddyHelper = new BuddyStorageHelper();
            var buddyList = buddyHelper.RetrieveBuddies(surferCompleteKey);

            foreach (Surfer b in buddyList)
            {
                var buddyDeleter = new BuddyStorageHelper(surferCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(b.PartitionKey, b.RowKey));

                buddyDeleter.Delete();
            }

            //Delete his CommentsAboutMe and CommentsByMe references, and the Comments themselves
            var commentHelper = new CommentStorageHelper();

            //CommentsAboutMe
            var commentsAboutMeHelper = new CommentsAboutMeStorageHelper();
            var commentsAboutMeList = commentsAboutMeHelper.RetrieveComments(surferCompleteKey);

            foreach (Comment c in commentsAboutMeList)
            {
                var commentsAboutMeDeleter = new CommentsAboutMeStorageHelper(surferCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(c.PartitionKey, c.RowKey));

                commentsAboutMeDeleter.Delete();
                commentHelper.Delete(c);
            }

            //CommentsByMe
            var commentsByMeHelper = new CommentsByMeStorageHelper();
            var commentsByMeList = commentsByMeHelper.RetrieveComments(surferCompleteKey);

            foreach (Comment c in commentsByMeList)
            {
                var commentsByMeDeleter = new CommentsByMeStorageHelper(surferCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(c.PartitionKey, c.RowKey));

                commentsByMeDeleter.Delete();
                commentHelper.Delete(c);
            }

            //Delete his Session Collections
            var sessionCollectionHelper = new SessionCollectionStorageHelper();
            var sessionList = sessionCollectionHelper.RetrieveSessions(surferCompleteKey);

            foreach (Session s in sessionList)
            {
                var sessionCollectionDeleter = new SessionCollectionStorageHelper(surferCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(s.PartitionKey, s.RowKey));

                sessionCollectionDeleter.Delete();
            }

            //Delete Rows in Buddies table (where other surfers followed this guy)
            //Put something in a queue for an Azure Worker Role to delete.

            //Delete Rows in ThereNow table (where this surfer was at a session or break)
            //Put something in a queue for an Azure Worker Role to delete.
        }
    }
}
