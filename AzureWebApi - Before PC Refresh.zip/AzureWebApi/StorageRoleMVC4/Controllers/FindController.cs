﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class FindController : ApiController
    {
        public Dictionary<string, string> Get([FromUri] string searchString, [FromUri] string searchObject)
        {
            var searchHelper = new FindStorageHelper(searchObject);
            var objectList = searchHelper.Retrieve(searchString);

            return objectList;
        }

        public List<Break> Get(double latitude, double longitude)
        {
            var breakHelper = new BreakStorageHelper();
            var breakList = breakHelper.RetrieveBreaksNearby(latitude, longitude);

            return breakList;
        }
    }
}