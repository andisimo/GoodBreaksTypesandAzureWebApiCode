﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class SurfersController : ApiController
    {
        //Create a new user, store and hash password, return hash salt
        public HttpResponseMessage Post([FromBody] Surfer surfer, [FromUri] string password)
        {
            if (surfer.Region == null || surfer.Region == "" || surfer.PartitionKey == null || surfer.PartitionKey == ""
                || surfer.RowKey == null || surfer.RowKey == "" || surfer.Email == null || surfer.Email == "")
            {
                var errorResponse = Request.CreateResponse(HttpStatusCode.BadRequest);
                errorResponse.Content = new StringContent(@"You can't create a surfer with a 
                    NULL Email, Region, PartitionKey, or RowKey. You should use the non-default constructor to create 
                    the Surfer object you pass to this API method, and then ensure that you manually set the Email property.");
                throw new HttpResponseException(errorResponse);
            }

            var surferHelper = new SurferStorageHelper();
            string hashSalt = surferHelper.Save(surfer, password);

            var response = Request.CreateResponse(HttpStatusCode.OK, hashSalt);
            return response;
        }

        //Use the email to retrieve and return the surfer's salt and completekey
        public string[] Get(string email)
        {
            var securityHelper = SecurityStorageHelper.RetrieveByEmail(email);
            
            return new string[] {securityHelper.HashSalt, TableStorageHelper.ConstructCompleteKey
                (securityHelper.PartitionKey, securityHelper.RowKey) };
        }

        public Surfer Get([FromUri]string surferPK, string surferRK)
        {
            var helper = new SurferStorageHelper();
            var surfer = helper.Retrieve(partitionKey: surferPK, rowKey: surferRK);

            return surfer;
        }

        public HttpResponseMessage Put([FromBody] Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Update(surfer);

            var response = Request.CreateResponse(HttpStatusCode.OK, surfer);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Delete(surfer);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
