﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using System.Net.Http;
using System.Net;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfBreaksController : ApiController
    {
        public List<Break> Get(string relatedObjectPK, string relatedObjectRK)
        {
            var helper = new BreakCollectionStorageHelper();
            var breakList = helper.RetrieveBreaks(
                TableStorageHelper.ConstructCompleteKey(relatedObjectPK, relatedObjectRK));

            return breakList;
        }

        public HttpResponseMessage Post(string relatedObjectCompleteKey, string breakCompleteKey)
        {
            var helper = new BreakCollectionStorageHelper();
            helper.PartitionKey = relatedObjectCompleteKey;
            helper.RowKey = breakCompleteKey;
            helper.Upsert();

            return new HttpResponseMessage(HttpStatusCode.Created);
        }

        public HttpResponseMessage Delete(string relatedObjectCompleteKey, string breakCompleteKey)
        {
            var helper = new BreakCollectionStorageHelper();
            helper.PartitionKey = relatedObjectCompleteKey;
            helper.RowKey = breakCompleteKey;
            helper.Delete();

            return new HttpResponseMessage(HttpStatusCode.OK);
        }
    }
}