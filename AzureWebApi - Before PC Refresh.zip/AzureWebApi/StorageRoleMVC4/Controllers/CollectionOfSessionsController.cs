﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using System.Net.Http;
using System.Net;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfSessionsController : ApiController
    {
        public List<Session> Get(string relatedObjectPK, string relatedObjectRK)
        {
            var helper = new SessionCollectionStorageHelper();
            var sessionList = helper.RetrieveSessions(
                TableStorageHelper.ConstructCompleteKey(relatedObjectPK, relatedObjectRK));

            return sessionList;
        }

        public HttpResponseMessage Post(string relatedObjectCompleteKey, string sessionCompleteKey)
        {
            var helper = new SessionCollectionStorageHelper();
            helper.PartitionKey = relatedObjectCompleteKey;
            helper.RowKey = sessionCompleteKey;
            helper.Upsert();

            return new HttpResponseMessage(HttpStatusCode.Created);
        }

        public HttpResponseMessage Delete(string relatedObjectCompleteKey, string sessionCompleteKey)
        {
            var helper = new SessionCollectionStorageHelper();
            helper.PartitionKey = relatedObjectCompleteKey;
            helper.RowKey = sessionCompleteKey;
            helper.Delete();

            return new HttpResponseMessage(HttpStatusCode.Created);
        }
    }
}
