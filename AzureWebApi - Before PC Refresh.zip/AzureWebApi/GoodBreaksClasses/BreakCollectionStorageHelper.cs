﻿using System;
using System.Collections.Generic;
using System.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.Data.Services.Client;

namespace GoodBreaksClasses
{
    public class BreakCollectionStorageHelper : TableServiceEntity, ICollectionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "BreakCollections";

        //constructors
        public BreakCollectionStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                   (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        public BreakCollectionStorageHelper(string relatedObjectCompleteKey, string breakCompleteKey)
        {
            _storageAccount = CloudStorageAccount.Parse
               (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();

            PartitionKey = relatedObjectCompleteKey;
            RowKey = breakCompleteKey;
        }

        //methods
        public List<Break> RetrieveBreaks(string relatedObjectCompleteKey)
        {
            CloudTableQuery<BreakCollectionStorageHelper> partitionQuery =
                (from e in _serviceContext.CreateQuery<BreakCollectionStorageHelper>(_tableName)
                 where e.PartitionKey == relatedObjectCompleteKey
                 select e).AsTableServiceQuery<BreakCollectionStorageHelper>();

            var breakIdList = new List<string>();
            foreach (BreakCollectionStorageHelper b in partitionQuery)
            {
                string id = b.RowKey;
                breakIdList.Add(id);
            }

            var breakHelper = new BreakStorageHelper();
            var breakList = new List<Break>();
            foreach (string s in breakIdList)
            {
                var breakKeys = TableStorageHelper.ParseCompleteKey(s);

                try
                {
                    var break1 = breakHelper.Retrieve(breakKeys["region"], breakKeys["id"]);
                    breakList.Add(break1);
                }
                catch (DataServiceQueryException)
                { }
            }

            return breakList;
        }

        public void Upsert()
        {
            //null e-tag - upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, this, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(this);
                _serviceContext.AttachTo(_tableName, this, null);
            }

            if (this.PartitionKey != null && this.RowKey != null)
            {
                _serviceContext.UpdateObject(this);
            }
            else
            {
                throw new InvalidOperationException("The current instance of" +
                    "BreakThereNowStorageHelper has a NULL value for either the PartitionKey" +
                    "propert, the RowKey property, or both.");
            }

            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete()
        {
            _serviceContext.AttachTo(_tableName, this, "*");
            _serviceContext.DeleteObject(this);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
