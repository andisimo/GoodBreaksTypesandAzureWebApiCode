﻿using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System;

namespace GoodBreaksClasses
{
    class BreakThereNowStorageHelper : TableServiceEntity
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "ThereNow";

        //constructors
        public BreakThereNowStorageHelper(string breakCompleteKey, string surferCompleteKey)
        {
            _storageAccount = CloudStorageAccount.Parse
               (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();

            var helper = new TableStorageHelper();
            var breakKeys = helper.ParseCompleteKey(breakCompleteKey);
            var surferKeys = helper.ParseCompleteKey(surferCompleteKey);

            PartitionKey = breakCompleteKey;
            RowKey = surferCompleteKey;
        }

        //methods
        public BreakThereNowStorageHelper Retrieve(string partitionKey, string rowKey)
        {
            BreakThereNowStorageHelper helper =
                (from getThis in _serviceContext.CreateQuery<BreakThereNowStorageHelper>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return helper;
        }

        public void Save(BreakThereNowStorageHelper itemToSave)
        {
            _serviceContext.AddObject(_tableName, itemToSave);

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(BreakThereNowStorageHelper itemToSave)
        {
            _serviceContext.UpdateObject(itemToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(BreakThereNowStorageHelper itemToSave)
        {
            //null e-tag - step 1 to the inscrutable means of Upserting
            try
            {
                _serviceContext.AttachTo(_tableName, itemToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(itemToSave);
                _serviceContext.AttachTo(_tableName, itemToSave, null);
            }

            _serviceContext.UpdateObject(itemToSave);
            //no SaveChangesOption applied - step 2, indicating merge not replace. 
            //This should upsert. 
            _serviceContext.SaveChanges();
        }

        public void Delete(BreakThereNowStorageHelper breakThereNowToDelete)
        {
            _serviceContext.AttachTo(_tableName, breakThereNowToDelete, "*");
            _serviceContext.DeleteObject(breakThereNowToDelete);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
