﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class BreaksController : ApiController
    {
        public Break Get([FromUri] string breakPK, string breakRK)
        {
            var helper = new BreakStorageHelper();
            Break break1 = helper.Retrieve(breakPK, breakRK);

            return break1;
        }

        public List<Break> Get([FromUri] string partitionKey)
        {
            var helper = new BreakStorageHelper();
            var breakList = helper.RetrieveBreaksInPartition(partitionKey);

            return breakList;
        }

        public HttpResponseMessage Post([FromBody]Break break1)
        {
            var helper = new BreakStorageHelper();
            helper.Save(break1);

            var response = Request.CreateResponse<Break>(HttpStatusCode.Created, break1);
            return response;
        }

        public HttpResponseMessage Put([FromBody] Break break1)
        {
            var helper = new BreakStorageHelper();
            helper.Upsert(break1);

            var response = Request.CreateResponse<Break>(HttpStatusCode.OK, break1);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Break break1)
        {
            var helper = new BreakStorageHelper();
            helper.Delete(break1);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        //Add surfer to Break.ThereNow
        public HttpResponseMessage Put([FromUri] string surferCompleteKey, string breakCompleteKey)
        {
            var tableHelper = new TableStorageHelper();
            Dictionary<string, string> surferKeys = tableHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> breakKeys = tableHelper.ParseCompleteKey(breakCompleteKey);

            var breakHelper = new BreakStorageHelper();
            breakHelper.AddSurferToThereNow(surferKeys["region"], surferKeys["id"], breakKeys["region"], breakKeys["id"]);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        //Remove surfer from Break.ThereNow
        public HttpResponseMessage Delete([FromUri] string surferCompleteKey, string breakCompleteKey)
        {
            var tableHelper = new TableStorageHelper();
            Dictionary<string, string> surferKeys = tableHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> breakKeys = tableHelper.ParseCompleteKey(breakCompleteKey);

            var breakHelper = new BreakStorageHelper();
            breakHelper.RemoveSurferFromThereNow(surferKeys["region"], surferKeys["id"], breakKeys["region"], breakKeys["id"]);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}