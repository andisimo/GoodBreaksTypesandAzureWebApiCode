﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfCommentsAboutMeController : ApiController
    {
        public List<Comment> Get(string aboutObjectPK, string aboutObjectRK)
        {
            var helper = new CommentsAboutMeStorageHelper();
            var commentList = helper.RetrieveComments(
                TableStorageHelper.ConstructCompleteKey(aboutObjectPK, aboutObjectRK));

            return commentList;
        }

        //NECESSARY??
        //public HttpResponseMessage Delete(string aboutObjectPK, string aboutObjectRK)
        //{
        //    var helper = new CommentsAboutMeStorageHelper();
        //    helper.PartitionKey = TableStorageHelper.ConstructCompleteKey(aboutObjectPK, aboutObjectRK);

        //    var comments = helper.RetrieveComments(TableStorageHelper.ConstructCompleteKey(aboutObjectPK, aboutObjectRK));
        //    foreach (Comment c in comments)
        //    {
        //        helper.RowKey = TableStorageHelper.ConstructCompleteKey(c.PartitionKey, c.RowKey);
        //        helper.Delete();
        //    }

        //    var response = Request.CreateResponse(HttpStatusCode.OK);
        //    return response;
        //}

        //public HttpResponseMessage Delete(string aboutObjectPK, string aboutObjectRK, string commentPK, string commentRK)
        //{
        //    var helper = new CommentsAboutMeStorageHelper();
        //    helper.PartitionKey = TableStorageHelper.ConstructCompleteKey(aboutObjectPK, aboutObjectRK);
        //    helper.RowKey = TableStorageHelper.ConstructCompleteKey(commentPK, commentRK);
        //    helper.Delete();

        //    var response = Request.CreateResponse(HttpStatusCode.OK);
        //    return response;
        //}
    }
}
