﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfCommentsByMeController : ApiController
    {
        public List<Comment> Get(string commenterPK, string commenterRK)
        {
            var helper = new CommentsByMeStorageHelper();
            var commentList = helper.RetrieveComments(
                TableStorageHelper.ConstructCompleteKey(commenterPK, commenterRK));

            return commentList;
        }
    }
}
