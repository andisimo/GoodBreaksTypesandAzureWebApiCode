﻿using System.Linq;
using OAuth2.Mvc;

namespace StorageRoleMVC4.OAuth
{
    public class OAuthIdentity : OAuthIdentityBase
    {
        public OAuthIdentity(IOAuthProvider provider, string token)
            : base(provider)
        {
            Token = token;
            Realm = "Demo";
        }

        protected override void Load()
        {
            var token = OAuthService.Tokens.FirstOrDefault(t => t.AccessToken == Token && !t.IsAccessExpired);
            if (token == null)
                return;

            IsAuthenticated = true;
            Name = token.Name;
        }
    }
}