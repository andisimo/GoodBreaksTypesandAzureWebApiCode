﻿using System.Security.Principal;
using OAuth2.Mvc;

namespace StorageRoleMVC4.OAuth
{
    public class OAuthPrincipal : OAuthPrincipalBase
    {
        public OAuthPrincipal(IOAuthProvider provider, IIdentity identity)
            : base(provider, identity)
        { }

        protected override void Load()
        {
            Roles = new[] {"User"};
        }
    }
}