﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SessionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SessionsBreaks";

        //public fields
        public Session sessionInQuestion; 

        //Constructor
        public SessionStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Session Retrieve(string partitionKey, string rowKey)
        {
            Session session =
                (from getThis in _serviceContext.CreateQuery<Session>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return session;
        }

        public void Save(Session session)
        {
            _serviceContext.AddObject(_tableName, session); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(Session session)
        {
            _serviceContext.UpdateObject(session);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Session sessionToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, sessionToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(sessionToSave);
                _serviceContext.AttachTo(_tableName, sessionToSave, null);
            }

            _serviceContext.UpdateObject(sessionToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Session sessionToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, sessionToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(sessionToDelete);
                _serviceContext.AttachTo(_tableName, sessionToDelete, "*");
            }

            _serviceContext.DeleteObject(sessionToDelete);
            _serviceContext.SaveChanges();
        }
    }
}
