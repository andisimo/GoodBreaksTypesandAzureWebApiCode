﻿using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System;
using System.Collections.Generic;
using GoodBreaksTypes;

namespace GoodBreaksClasses
{
    public class ThereNowStorageHelper : TableServiceEntity
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "ThereNow";

        //constructors
        public ThereNowStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                   (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        public ThereNowStorageHelper(string placeCompleteKey, string surferCompleteKey)
        {
            _storageAccount = CloudStorageAccount.Parse
               (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();

            PartitionKey = placeCompleteKey;
            RowKey = surferCompleteKey;
        }

        //methods
        public List<Surfer> RetrieveSurfersThereNow(string partitionKey)
        {
            CloudTableQuery<ThereNowStorageHelper> partitionQuery =
                (from e in _serviceContext.CreateQuery<ThereNowStorageHelper>(_tableName)
                 where e.PartitionKey == partitionKey
                 select e).AsTableServiceQuery<ThereNowStorageHelper>();

            var thereNowIdList = new List<string>();
            foreach (ThereNowStorageHelper b in partitionQuery)
            {
                string id = b.RowKey;
                thereNowIdList.Add(id);
            }

            var surferHelper = new SurferStorageHelper();
            var surferList = new List<Surfer>();
            foreach (string s in thereNowIdList)
            {
                var completeKey = TableStorageHelper.ParseCompleteKey(s);
                var surfer = surferHelper.Retrieve(completeKey["region"], completeKey["id"]);
                surferList.Add(surfer);
            }

            return surferList;
        }

        public void Upsert()
        {
            //null e-tag - upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, this, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(this);
                _serviceContext.AttachTo(_tableName, this, null);
            }

            if (this.PartitionKey != null && this.RowKey != null)
            {
                _serviceContext.UpdateObject(this);
            }
            else
            {
                throw new InvalidOperationException("The current instance of" +
                    "BreakThereNowStorageHelper has a NULL value for either the PartitionKey" +
                    "propert, the RowKey property, or both.");
            }

            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete()
        {
            _serviceContext.AttachTo(_tableName, this, "*");
            _serviceContext.DeleteObject(this);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
