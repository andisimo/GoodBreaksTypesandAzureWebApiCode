﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfSessionsController : ApiController
    {
        public List<Session> Get(string relatedObjectPK, string relatedObjectRK)
        {
            var helper = new SessionCollectionStorageHelper();
            var sessionList = helper.RetrieveSessions(
                TableStorageHelper.ConstructCompleteKey(relatedObjectPK, relatedObjectRK));

            return sessionList;
        }
    }
}
