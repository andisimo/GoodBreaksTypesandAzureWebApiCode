﻿using System;
using System.Globalization;
using System.Data.Services.Common;
using System.Reflection;

namespace GoodBreaksWP7.Models
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Comment
    {

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string AboutKey { get; set; }
        public string FromSurferKey { get; set; }
        public string CommentText { get; set; }
        public Surfer FromSurfer { get; set; }
        public ICommentable About { get; set; }
        public Type AboutType { get; set; }
        public DateTime CommentDateTime { get; set; }

        //constructors
        public Comment()
        {}

         public Comment(string text, Surfer fromSurfer, ICommentable commentAbout)
        {
            CommentText = text;
            FromSurfer = fromSurfer;
            CommentDateTime = DateTime.UtcNow;
            About = commentAbout;
            AboutType = commentAbout.GetType();
            commentAbout.AddComment(this);
            PartitionKey = FromSurfer.PartitionKey;
            RowKey = "com-" + Guid.NewGuid().ToString();
        }
    }
}
