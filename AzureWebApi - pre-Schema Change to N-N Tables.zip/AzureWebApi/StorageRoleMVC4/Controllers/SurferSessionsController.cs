﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class SurferSessionsController : ApiController
    {
        public List<Session> Get(string surferPK, string surferRK)
        {
            var helper = new SurferStorageHelper();
            var commentList = helper.RetrieveSessions(surferPK, surferRK);

            return commentList;
        }
    }
}
