﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksTypes;
using GoodBreaksClasses;

namespace StorageRoleMVC4.Controllers
{
    public class SampleDataController : ApiController
    {
        public void Get(string tableName)
        {
            var helper = new TableStorageHelper();
            helper._tableClient.DeleteTableIfExist(tableName);
        }

        public void Get(string tableName, string dummy)
        {
            var helper = new TableStorageHelper();
            helper._tableClient.CreateTableIfNotExist(tableName);
        }

        public void get(string surferName, string breakName, string dummy)
        {
            var surfer = new Surfer("George", "Schultz", "USWC");
            surfer.RowKey = "sur-4c3261d8-3b1a-4bd4-8850-4d769cfbd7ef";
            
            var surfer2 = new Surfer("Helpga", "Schultz", "USWC");
            surfer2.RowKey = "sur-12";

            var surfer3 = new Surfer("Brad", "Smith", "USWC");
            surfer3.RowKey = "sur-6a3261d8-3b1a-4bd4-8850-4d769cfbd7fg";
            
            var surferHelper = new SurferStorageHelper();
            surferHelper.Upsert(surfer);
            surferHelper.Upsert(surfer2);
            surferHelper.Upsert(surfer3);
            surferHelper.AddBuddyToCollection(surfer.PartitionKey, surfer.RowKey, surfer3.PartitionKey, surfer3.RowKey);
            surferHelper.AddBuddyToCollection(surfer.PartitionKey, surfer.RowKey, surfer2.PartitionKey, surfer2.RowKey);

            var break1 = new Break("Salt Creek", 33.474336875045324, -117.72346615834977, "USWC");
            break1.RowKey = "bre-111de571-7142-47c8-bdb3-0eddd59f6ccd";

            var break2 = new Break("Lowers", 33.38297036756884, -117.59092211766983, "USWC");
            break2.RowKey = "bre-222de571-7142-47c8-bdb3-0eddd59f6a12";
            
            var breakHelper = new BreakStorageHelper();
            breakHelper.Upsert(break1);
            breakHelper.Upsert(break2);

            var session = new Session(break1, new DateTime(2012, 9, 12, 8, 30, 0), new DateTime(2012, 9, 12, 10, 30, 0));
            session.RowKey = "ses-222de571-7142-47c8-bdb3-0eddd59f6ccd";
            
            var sessionHelper = new SessionStorageHelper();
            sessionHelper.Upsert(session);
            sessionHelper.AddSurfer(session.PartitionKey, session.RowKey, surfer.PartitionKey, surfer.RowKey);
            sessionHelper.AddSurfer(session.PartitionKey, session.RowKey, surfer2.PartitionKey, surfer2.RowKey);
            sessionHelper.AddSurfer(session.PartitionKey, session.RowKey, surfer3.PartitionKey, surfer3.RowKey);

            //var comment = new Comment("This is the sample comment 1", surfer, session);
            //comment.CommentDateTime = new DateTime(2012, 9, 12, 8, 11, 11, 12);
            //var comment1 = new Comment("This is the sample comment 2", surfer1, break1);
            //comment.CommentDateTime = new DateTime(2012, 9, 12, 9, 11, 11, 12);
            //var commentHelper = new CommentStorageHelper();
            //var badprops = commentHelper.TroubleshootInvalidInputError(comment);
            //var badprops1 = commentHelper.TroubleshootInvalidInputError(comment1);
            //commentHelper.Upsert(comment);
            //commentHelper.Upsert(comment1); 

            var thereNow = new BreakThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey));
            var thereNow1 = new BreakThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey));
            var thereNow2 = new BreakThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey));

            thereNow.Upsert();
            thereNow1.Upsert();
            thereNow2.Upsert();
        }
    }
}
