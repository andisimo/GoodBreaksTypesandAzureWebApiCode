﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class BreaksController : ApiController
    {
        public Break Get([FromUri] string breakPK, string breakRK)
        {
            var helper = new BreakStorageHelper();
            Break break1 = helper.Retrieve(breakPK, breakRK);

            return break1;
        }

        public List<Break> Get([FromUri] string partitionKey)
        {
            var helper = new BreakStorageHelper();
            var breakList = helper.RetrieveBreaksInPartition(partitionKey);

            return breakList;
        }

        public HttpResponseMessage Post([FromBody]Break break1)
        {
            var helper = new BreakStorageHelper();
            helper.Save(break1);

            var response = Request.CreateResponse<Break>(HttpStatusCode.Created, break1);
            return response;
        }

        public HttpResponseMessage Put([FromBody] Break break1)
        {
            var helper = new BreakStorageHelper();
            helper.Upsert(break1);

            var response = Request.CreateResponse<Break>(HttpStatusCode.OK, break1);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Break break1)
        {
            var helper = new BreakStorageHelper();
            helper.Delete(break1);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}