﻿using System.Collections.Generic;

namespace GoodBreaksWP7.Models
{
    public interface ICommentable
    {
        SortedCommentList CommentsAboutMe
        { get; set; }

        void AddComment(Comment comment);
    }
}
