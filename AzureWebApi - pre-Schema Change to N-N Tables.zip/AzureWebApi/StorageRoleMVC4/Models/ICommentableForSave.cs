﻿using System.Collections.Generic;
using GoodBreaksWP7.Models;

namespace StorageRoleMVC4.Models
{
    public interface ICommentableForSave
    {
        Comment CommentToPointTo { get; set; }

        void UpdateCommentsAbout();
    
        void UpdateCommentsFrom();
    }
}