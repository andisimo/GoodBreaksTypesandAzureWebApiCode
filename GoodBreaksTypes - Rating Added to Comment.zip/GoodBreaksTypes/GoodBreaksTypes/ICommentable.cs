﻿using System.Collections.Generic;

namespace GoodBreaksTypes
{
    public interface ICommentable
    {
        //properties
        string Name { get; set; }
        string PartitionKey { get; set; }
        string RowKey { get; set; }
        SortedCommentList CommentsAboutMe { get; set; }

        //methods
        void AddComment(Comment comment);
    }
}
