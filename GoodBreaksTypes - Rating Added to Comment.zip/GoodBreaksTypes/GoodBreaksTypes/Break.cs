﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Services.Common;
using Newtonsoft.Json;

namespace GoodBreaksTypes
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Break : ICommentable, INotifyPropertyChanged
    {
        //fields
        private SortedCommentList _commentsAboutMe = new SortedCommentList();
        private ICollection<Surfer> _thereNow = new List<Surfer>();
        private string _region;

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string Name { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Region 
        {
            get
            {
                return _region;
            }
            set
            {
                _region = value;
                PartitionKey = value;
            }
        }

        [JsonIgnore]
        public SortedCommentList CommentsAboutMe
        {
            get { return _commentsAboutMe; }
            set 
            {
                if (_commentsAboutMe != value)
                {
                    _commentsAboutMe = value;
                    NotifyPropertyChanged("CommentsAboutMe");
                }
            }
        }

        [JsonIgnore]
        public ICollection<Surfer> ThereNow
        {
            get { return _thereNow; }
            set
            {
                if (_thereNow != value)
                {
                    _thereNow = value;
                    NotifyPropertyChanged("ThereNow");
                }
            }
        }

        //Constructors
        public Break()
        { }
        public Break(string breakName, double locLatitude, double locLongitude, string region)
        {
            Name = breakName;
            Latitude = locLatitude;
            Longitude = locLongitude;
            Region = region;
            RowKey = "bre-" + Guid.NewGuid().ToString();
        }

        //Methods
        public void AddComment(Comment comment)
        {
            CommentsAboutMe.Add(comment);
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            var handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
