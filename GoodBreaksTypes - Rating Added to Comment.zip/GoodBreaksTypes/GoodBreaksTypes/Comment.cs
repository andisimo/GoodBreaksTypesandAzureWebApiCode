﻿using System;
using System.Data.Services.Common;

namespace GoodBreaksTypes
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Comment
    {
        //fields
        private DateTime _timeStamp;
        private int? _rating;

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string AboutKey { get; set; }
        public string FromSurferKey { get; set; }
        public string CommentText { get; set; }
        public Surfer FromSurfer { get; set; }
        public ICommentable About { get; set; }
        public DateTime Timestamp { get { return _timeStamp; } }
        public int? Rating 
        {
            get { return _rating; }
            set
            {
                if (value < 0)
                {
                    _rating = 0;
                }
                else if (value <= 5)
                {
                    _rating = value;
                }
                else if (value > 5)
                {
                    _rating = 5;
                }
            }
        }

        //constructors
        public Comment()
        {
            _timeStamp = DateTime.UtcNow;
        }

        public Comment(string text, Surfer fromSurfer, ICommentable commentAbout)
        {
            _timeStamp = DateTime.UtcNow;
            CommentText = text;
            FromSurfer = fromSurfer;
            FromSurfer.CommentsByMe.Add(this);
            About = commentAbout;
            commentAbout.AddComment(this);
            AboutKey = KeyBuilder.BuildAboutKey(this, About);
            FromSurferKey = KeyBuilder.BuildFromKey(fromSurfer);
            PartitionKey = FromSurfer.PartitionKey;
            RowKey = "com-" + Guid.NewGuid().ToString();
        }

        public Comment(string text, Surfer fromSurfer, ICommentable commentAbout, int rating)
        {
            _timeStamp = DateTime.UtcNow;
            CommentText = text;
            FromSurfer = fromSurfer;
            FromSurfer.CommentsByMe.Add(this);
            About = commentAbout;
            commentAbout.AddComment(this);
            AboutKey = KeyBuilder.BuildAboutKey(this, About);
            FromSurferKey = KeyBuilder.BuildFromKey(fromSurfer);
            PartitionKey = FromSurfer.PartitionKey;
            RowKey = "com-" + Guid.NewGuid().ToString();
            Rating = rating; 
        }
    }
}
