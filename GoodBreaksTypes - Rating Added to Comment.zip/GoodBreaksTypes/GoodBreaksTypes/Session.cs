﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Services.Common;
using Newtonsoft.Json;

namespace GoodBreaksTypes
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Session : ICommentable, INotifyPropertyChanged 
    {
        //fields
        private List<Surfer> _surfersAtSession = new List<Surfer>();
        private SortedCommentList _commentsAboutMe = new SortedCommentList();
        private SortedCommentList _commentsByMe = new SortedCommentList();

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string BreakKey { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public Break SessionBreak { get; set; }
        public string Region { get; set; }
        public string Name { get; set; }

        [JsonIgnore]
        public ICollection<Surfer> SurfersAtSession
        {
            get { return _surfersAtSession; }
            set { _surfersAtSession = value as List<Surfer>; }
        }

        [JsonIgnore]
        public SortedCommentList CommentsAboutMe
        {
            get
            {
                return _commentsAboutMe;
            }
            set
            {
                if(_commentsAboutMe != value)
                {
                    _commentsAboutMe = value;
                    NotifyPropertyChanged("CommentsAboutMe");
                }
            }
        }

        //constructors
        public Session()
        { }

        public Session(Break sessionBreak, DateTime start, DateTime finish)
        {
            PartitionKey = sessionBreak.Region;
            RowKey = "ses-" + Guid.NewGuid();
            StartTime = start;
            EndTime = finish;
            SessionBreak = sessionBreak;
            BreakKey = sessionBreak.PartitionKey + "|" + sessionBreak.RowKey;
            Region = sessionBreak.Region;
            Name = sessionBreak.Name + " on " + start.Date.ToString();
        }
        
        //methods
        public void AddSurfer(Surfer surferToAdd)
        {
            SurfersAtSession.Add(surferToAdd);
            surferToAdd.Sessions.Add(this);
        }

        public ICollection<Surfer> RemoveSurfer(Surfer surferToRemove)
        {
            SurfersAtSession.Remove(surferToRemove);
            surferToRemove.Sessions.Remove(this); 
            return SurfersAtSession;
        }

        public void AddComment(Comment comment)
        {
            CommentsAboutMe.Comments.Add(comment);
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
