﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using System.Net.Http;
using System.Net;

namespace StorageRoleMVC4.Controllers
{
    public class BreakSurfersController : ApiController
    {
        public List<Surfer> Get(string breakCompleteKey)
        {
            var breakThereHelper = new ThereNowStorageHelper();
            var surferList = breakThereHelper.RetrieveSurfersThereNow(breakCompleteKey);

            return surferList;
        }

        //Add surfer to Break.ThereNow
        public HttpResponseMessage Post([FromUri] string surferCompleteKey, string breakCompleteKey)
        {
            Dictionary<string, string> surferKeys = TableStorageHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> breakKeys = TableStorageHelper.ParseCompleteKey(breakCompleteKey);

            var breakHelper = new BreakStorageHelper();
            breakHelper.AddSurferToThereNow(surferKeys["region"], surferKeys["id"], breakKeys["region"], breakKeys["id"]);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        //Remove surfer from Break.ThereNow
        public HttpResponseMessage Delete([FromUri] string surferCompleteKey, string breakCompleteKey)
        {
            Dictionary<string, string> surferKeys = TableStorageHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> breakKeys = TableStorageHelper.ParseCompleteKey(breakCompleteKey);

            var breakHelper = new BreakStorageHelper();
            breakHelper.RemoveSurferFromThereNow(surferKeys["region"], surferKeys["id"], breakKeys["region"], breakKeys["id"]);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
