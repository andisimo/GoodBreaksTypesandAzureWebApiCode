﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SurferStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SurfersComments";
        

        //private fields
        private int _totalBuddies;
        private int _totalSessions;
        private int _highestCommentIndex;
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //Constructor
        public SurferStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Surfer Retrieve(string partitionKey, string rowKey)
        {
            Surfer surfer =
                (from getThis in _serviceContext.CreateQuery<Surfer>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return surfer;
        }

        public List<Surfer> RetrieveBuddies(string surferPK, string surferRK)
        {
            var buddyIdList = new List<string>();

            var buddyHelper = new BuddyStorageHelper();
            var buddyList = buddyHelper.RetrieveBuddies(TableStorageHelper.ConstructCompleteKey(
                surferPK, surferRK));

            return buddyList;
        }

        public List<Session> RetrieveSessions(string surferPK, string surferRK)
        {
            var sessionCollectionHelper = new SessionCollectionStorageHelper();
            var sessionList = sessionCollectionHelper.RetrieveSessions(
                TableStorageHelper.ConstructCompleteKey(surferPK, surferRK));

            return sessionList;
        }

        public List<Comment> RetrieveCommentsAboutMe(string surferPK, string surferRK)
        {
            var commentsAboutMeHelper = new CommentsAboutMeStorageHelper();
            var commentList = commentsAboutMeHelper.RetrieveComments(
                TableStorageHelper.ConstructCompleteKey(surferPK, surferRK));

            return commentList;
        }

        public List<Comment> RetrieveCommentsByMe(string surferPK, string surferRK)
        {
            var commentByMeHelper = new CommentsByMeStorageHelper();
            var commentList = commentByMeHelper.RetrieveComments(
                TableStorageHelper.ConstructCompleteKey(surferPK, surferRK));

            return commentList;
        }

        public void Save(Surfer surfer)
        {
            _serviceContext.AddObject(_tableName, surfer); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(Surfer surfer)
        {
            _serviceContext.UpdateObject(surfer);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Surfer surferToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToSave);
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }

            _serviceContext.UpdateObject(surferToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Surfer surferToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToDelete);
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }

            _serviceContext.DeleteObject(surferToDelete);
            _serviceContext.SaveChangesWithRetries();
        }

        public void AddBuddyToCollection(string surferPK, string surferRK, string buddyPK, string buddyRK)
        {
            var buddyHelper = new BuddyStorageHelper();
            buddyHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(surferPK, surferRK);
            buddyHelper.RowKey = TableStorageHelper.ConstructCompleteKey(buddyPK, buddyRK);

            buddyHelper.Upsert();
        }

        public void AddSessionToCollection(string surferPK, string surferRK, string sessionPK, string sessionRK)
        {
            var sessionCollectionHelper = new SessionCollectionStorageHelper();
            sessionCollectionHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(
                surferPK, surferRK);
            sessionCollectionHelper.RowKey = TableStorageHelper.ConstructCompleteKey(
                sessionPK, sessionRK);

            sessionCollectionHelper.Upsert();
        }
    }
}
