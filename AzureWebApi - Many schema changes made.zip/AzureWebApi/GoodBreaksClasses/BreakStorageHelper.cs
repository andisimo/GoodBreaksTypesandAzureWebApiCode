﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class BreakStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SessionsBreaks";

        //private fields
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //Constructor
        public BreakStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Break Retrieve(string partitionKey, string rowKey)
        {
            Break break1=
                (from getThis in _serviceContext.CreateQuery<Break>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return break1;
        }

        public List<Break> RetrieveBreaksInPartition(string partitionKey)
        {
            CloudTableQuery<Break> partitionQuery =
                (from e in _serviceContext.CreateQuery<Break>(_tableName)
                 where e.PartitionKey == partitionKey
                 select e).AsTableServiceQuery<Break>();

            var breakList = new List<Break>();
            foreach (Break b in partitionQuery)
            {
                if(b.RowKey.StartsWith("bre"))
                    breakList.Add(b);
            }

            return breakList;
        }

        public List<Comment> RetrieveCommentsAboutMe(string partitionKey, string rowKey)
        {
            var commentIdList = new List<string>();

            EventHandler<ReadingWritingEntityEventArgs> readingCommentsAboutDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                var propertyNode = e.Data.Descendants(_m + "properties").First();
                var properties = propertyNode.DescendantNodes();
                foreach (XNode node in properties)
                {
                    XElement element = node as XElement;
                    if (element != null)
                    {
                        string name = element.Name.ToString();

                        if (name.Contains("CommentsAboutMe"))
                        {
                            commentIdList.Add(element.Value);
                        }
                    }
                }
            };
            _serviceContext.ReadingEntity += readingCommentsAboutDelegate;
            Break break1 = Retrieve(partitionKey, rowKey);
            _serviceContext.ReadingEntity -= readingCommentsAboutDelegate;

            var commentList = new List<Comment>();
            var commentHelper = new CommentStorageHelper();
            foreach (string commentId in commentIdList)
            {
                var commentKeys = TableStorageHelper.ParseCompleteKey(commentId);
                var comment = commentHelper.Retrieve(commentKeys["region"], commentKeys["id"]);

                var surferKeys = TableStorageHelper.ParseCompleteKey(comment.FromSurferKey);
                var surferHelper = new SurferStorageHelper();
                comment.FromSurfer = surferHelper.Retrieve(surferKeys["region"], surferKeys["id"]);

                commentList.Add(comment);
            }

            return commentList;
        }

        public void Save(Break break1)
        {
            _serviceContext.AddObject(_tableName, break1); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Break breakToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, breakToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(breakToSave);
                _serviceContext.AttachTo(_tableName, breakToSave, null);
            }

            _serviceContext.UpdateObject(breakToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Update(Break breakToSave)
        {
            _serviceContext.UpdateObject(breakToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Delete(Break breakToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, breakToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(breakToDelete);
                _serviceContext.AttachTo(_tableName, breakToDelete, "*");
            }
            _serviceContext.DeleteObject(breakToDelete);
            _serviceContext.SaveChangesWithRetries();
        }

        public void AddSurferToThereNow(string surferPK, string surferRK, string breakPK, string breakRK)
        {
            var helper = new ThereNowStorageHelper(TableStorageHelper.ConstructCompleteKey(breakPK, breakRK),
                TableStorageHelper.ConstructCompleteKey(surferPK, surferRK));

            helper.Upsert();
        }

        public void RemoveSurferFromThereNow(string surferPK, string surferRK, string breakPK, string breakRK)
        {
            var helper = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(breakPK, breakRK),
                TableStorageHelper.ConstructCompleteKey(surferPK, surferRK));

            helper.Delete(); 
        }
    }
}
