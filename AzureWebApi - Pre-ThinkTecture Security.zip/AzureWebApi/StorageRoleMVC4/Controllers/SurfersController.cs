﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class SurfersController : ApiController
    {
        public Surfer Get([FromUri]string surferPK, string surferRK)
        {
            var helper = new SurferStorageHelper();
            var surfer = helper.Retrieve(partitionKey: surferPK, rowKey: surferRK);

            return surfer;
        }

        public HttpResponseMessage Post([FromBody]Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Save(surfer);

            var response = Request.CreateResponse<Surfer>(HttpStatusCode.Created, surfer);
            return response;
        }

        public HttpResponseMessage Put([FromBody] Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Upsert(surfer);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        public HttpResponseMessage Delete([FromBody] Surfer surfer)
        {
            var helper = new SurferStorageHelper();
            helper.Delete(surfer);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
