﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SessionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SessionsBreaks";

        //private fields
        private int _totalSurfersAt;
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //public fields
        public Session sessionInQuestion; 

        //Constructor
        public SessionStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Session Retrieve(string partitionKey, string rowKey)
        {
            Session session =
                (from getThis in _serviceContext.CreateQuery<Session>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return session;
        }

        public void Save(Session session)
        {
            _serviceContext.AddObject(_tableName, session); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(Session session)
        {
            _serviceContext.UpdateObject(session);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Session sessionToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, sessionToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(sessionToSave);
                _serviceContext.AttachTo(_tableName, sessionToSave, null);
            }

            _serviceContext.UpdateObject(sessionToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Session sessionToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, sessionToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(sessionToDelete);
                _serviceContext.AttachTo(_tableName, sessionToDelete, "*");
            }

            _serviceContext.DeleteObject(sessionToDelete);
            _serviceContext.SaveChanges();
        }

        public void AddSurfer(string sessionPK, string sessionRK, string surferPK, string surferRK)
        {
            _serviceContext.ReadingEntity += new EventHandler<ReadingWritingEntityEventArgs>(_serviceContext_ReadingFromEntity);
            _serviceContext.WritingEntity += new EventHandler<ReadingWritingEntityEventArgs>(_serviceContext_WritingFromEntity);

            var sessionFromStorage = Retrieve(sessionPK, sessionRK);

            var helper = new SurferStorageHelper();
            var surfer = helper.Retrieve(partitionKey: surferPK, rowKey: surferRK);

            sessionFromStorage.SurfersAtSession.Clear();
            sessionFromStorage.SurfersAtSession.Add(surfer);

            Update(sessionFromStorage);
            helper.AddSessionToCollection(surferPK: surferPK, surferRK: surferRK, sessionPK: sessionPK, sessionRK: sessionRK); 
        }

        private void _serviceContext_ReadingFromEntity(object sender, ReadingWritingEntityEventArgs e)
        {
            _totalSurfersAt = 0;
            var propertyNode = e.Data.Descendants(_m + "properties").First();
            var properties = propertyNode.DescendantNodes();
            foreach (XNode node in properties)
            {
                XElement element = node as XElement;
                if (element != null)
                {
                    string name = element.Name.ToString();

                    if (name.Contains("SurfersAtSession"))
                    {
                        int index = Int32.Parse(name.Substring(name.IndexOf("SurfersAtSession_") + 17));
                        if (index > _totalSurfersAt)
                            _totalSurfersAt = index;
                    }
                }
            }

            _serviceContext.ReadingEntity -= _serviceContext_ReadingFromEntity;
        }

        private void _serviceContext_WritingFromEntity(object sender, ReadingWritingEntityEventArgs e)
        {
            XElement properties;
            Session session = e.Entity as Session;

            if (session != null)
            {
                List<Surfer> surfersAtSession = session.SurfersAtSession.ToList<Surfer>(); 
                foreach (Surfer s in surfersAtSession)
                {
                    _totalSurfersAt++;
                    XElement propertyToAdd = new XElement(_d + "SurfersAtSession_" + _totalSurfersAt.ToString(), s.PartitionKey + "|" + s.RowKey);
                    properties = e.Data.Descendants(_m + "properties").First();
                    properties.Add(propertyToAdd);
                }
            }

            _serviceContext.WritingEntity -= _serviceContext_WritingFromEntity;
        }
    }
}
