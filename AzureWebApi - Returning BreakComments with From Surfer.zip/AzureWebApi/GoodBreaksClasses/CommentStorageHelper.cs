﻿using System;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class CommentStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SurfersComments";

        //private fields
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //Constructor
        public CommentStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Comment Retrieve(string partitionKey, string rowKey)
        {
            Comment comment =
                (from getThis in _serviceContext.CreateQuery<Comment>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return comment;
        }

        public void Save(Comment commentToSave)
        {
            _serviceContext.AddObject(_tableName, commentToSave);
            _serviceContext.IgnoreMissingProperties = true;

            _serviceContext.SaveChanges();

            var tableHelper = new TableStorageHelper();
            tableHelper.AddToCommentsAboutMe(itemToUpdate: commentToSave.About, comment: commentToSave);
            
            var surferHelper = new SurferStorageHelper();
            surferHelper.AddToCommentsByMe(surferToUpdate: commentToSave.FromSurfer, comment: commentToSave);
        }

        public void Update(Comment commentToSave)
        {
            _serviceContext.UpdateObject(commentToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Comment commentToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, commentToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(commentToSave);
                _serviceContext.AttachTo(_tableName, commentToSave, null);
            }

            _serviceContext.UpdateObject(commentToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Comment commentToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, commentToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(commentToDelete);
                _serviceContext.AttachTo(_tableName, commentToDelete, "*"); 
            }

            _serviceContext.DeleteObject(commentToDelete);
            _serviceContext.SaveChanges();
        }
    }
}
