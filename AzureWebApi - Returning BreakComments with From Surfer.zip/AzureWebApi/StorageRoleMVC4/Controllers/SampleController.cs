﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using Newtonsoft.Json;

namespace StorageRoleMVC4.Controllers
{
    public class SampleController : ApiController
    {
        //Sample Data - Refresh Tables
        public void Get([FromUri]string tableName)
        {
            TableStorageHelper surferHelper = new TableStorageHelper();
            if (surferHelper._tableClient.DoesTableExist(tableName))
            {
                surferHelper._tableClient.DeleteTable(tableName);
            }

            surferHelper._tableClient.CreateTableIfNotExist(tableName);
        }

        //Sample Data Post
        public HttpResponseMessage Get([FromUri]string firstName, string lastName)
        {
            var surfer = new Surfer(firstName, lastName, "USWC");
            surfer.NickName = "Shortness";
            surfer.Description = "Short guy";
            var helper = new SurferStorageHelper();
            helper.Save(surfer);

            var surfer2 = new Surfer("Floating", "Llama", "USWC");
            helper.Save(surfer2);

            var c1 = new Comment("Hey, you really do surf good!", surfer2, surfer);
            var cHelper = new CommentStorageHelper();
            cHelper.Save(c1);

            var c2 = new Comment("Nice wave.", surfer, surfer2);
            cHelper.Save(c2);

            //get Sample JSON for Fiddler from here
            Formatting formatting = new Formatting();
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            string json = JsonConvert.SerializeObject(surfer, formatting, settings);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        //Sample Session Post
        public string Get(int id)
        {
            //For Sample - Save New Session
            TableStorageHelper helper = new TableStorageHelper();

            HttpWebRequest request = HttpWebRequest.Create("http://127.0.0.2:8080/api/sessions/") as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "text/json";
            using (var writer = new StreamWriter(request.GetRequestStream()))
            {
                Session session = new Session(helper.Retrieve("Break", "USWC", "bre-28197a6a-f12d-4fdb-a87d-4abaa731437f"),
                    new DateTime(2012, 8, 25, 6, 0, 0), new DateTime(2012, 8, 25, 12, 0, 0));
                Formatting formatting = new Formatting();
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                string json = JsonConvert.SerializeObject(session, formatting, settings);

                writer.Write(json);
            }

            var response = request.GetResponse() as HttpWebResponse;
            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                var responseText = reader.ReadToEnd();
                return responseText;
            }
        }
    }
}
