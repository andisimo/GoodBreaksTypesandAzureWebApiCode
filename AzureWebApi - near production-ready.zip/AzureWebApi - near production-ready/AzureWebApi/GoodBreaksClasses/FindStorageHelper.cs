﻿using System;
using System.Collections.Generic;
using System.Data.Services.Common;
using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class FindStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SearchTable";

        //properties
        public string PartitionKey {get; set;}
        public string RowKey { get; set; }
        public string ObjectCompleteKey { get; set; }

        //Constructor
        public FindStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Dictionary<string, string> Retrieve(string searchTerm, string searchType)
        {
            CloudTableQuery<FindStorageHelper> result =
                (from getThis in _serviceContext.CreateQuery<FindStorageHelper>(_tableName)
                 select getThis).AsTableServiceQuery<FindStorageHelper>();

            var dictionary = new Dictionary<string, string>();

            foreach (FindStorageHelper searchResult in result)
            {
                if (searchResult.RowKey.ToLower().Contains(searchTerm.ToLower()))
                {
                    var keys = TableStorageHelper.ParseCompleteKey(searchResult.ObjectCompleteKey);

                    if (searchType == "Surfer")
                    {
                        if (keys["id"].ToLower().StartsWith("sur"))
                        {
                            dictionary.Add(searchResult.ObjectCompleteKey, searchResult.RowKey);
                        }
                    }
                    else if (searchType == "Break")
                    {
                        if (keys["id"].ToLower().StartsWith("bre"))
                        {
                            dictionary.Add(searchResult.ObjectCompleteKey, searchResult.RowKey);
                        }
                    }
                }
            }

            return dictionary;
        }


        public void Save(dynamic searchObject)
        {
            if(searchObject.RowKey.ToLower().StartsWith("sur"))
            {
                this.ObjectCompleteKey = TableStorageHelper.ConstructCompleteKey(
                    searchObject.PartitionKey, searchObject.RowKey);
                this.PartitionKey = "Surfer";
                this.RowKey = searchObject.Name;
            }
            else if (searchObject.RowKey.ToLower().StartsWith("bre"))
            {
                this.ObjectCompleteKey = TableStorageHelper.ConstructCompleteKey(
                    searchObject.PartitionKey, searchObject.RowKey);
                this.PartitionKey = "Break";
                this.RowKey = searchObject.Name;
            }

            _serviceContext.AddObject(_tableName, this); 

            _serviceContext.IgnoreMissingProperties = true;

            try
            {
                _serviceContext.SaveChanges();
            }
            catch (System.Data.Services.Client.DataServiceClientException ex1)
            {
                throw ex1;
            }
            catch (System.Data.Services.Client.DataServiceRequestException ex2)
            {
                throw ex2;
            }
        }

        public void Delete(FindStorageHelper searchItemToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, searchItemToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(searchItemToDelete);
                _serviceContext.AttachTo(_tableName, searchItemToDelete, "*");
            }
            _serviceContext.DeleteObject(searchItemToDelete);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
