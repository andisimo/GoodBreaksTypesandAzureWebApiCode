﻿using System;
using System.Collections.Generic;
using System.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.Data.Services.Client;

namespace GoodBreaksClasses
{
    public class SessionCollectionStorageHelper : TableServiceEntity, ICollectionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SessionCollections";

        //constructors
        public SessionCollectionStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                   (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        public SessionCollectionStorageHelper(string relatedObjectCompleteKey, string sessionCompleteKey)
        {
            _storageAccount = CloudStorageAccount.Parse
               (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();

            PartitionKey = relatedObjectCompleteKey;
            RowKey = sessionCompleteKey;
        }

        //methods
        public List<Session> RetrieveSessions(string relatedObjectCompleteKey)
        {
            CloudTableQuery<SessionCollectionStorageHelper> partitionQuery =
                (from e in _serviceContext.CreateQuery<SessionCollectionStorageHelper>(_tableName)
                 where e.PartitionKey == relatedObjectCompleteKey
                 select e).AsTableServiceQuery<SessionCollectionStorageHelper>();

            var sessionIdList = new List<string>();
            foreach (SessionCollectionStorageHelper s in partitionQuery)
            {
                string id = s.RowKey;
                sessionIdList.Add(id);
            }

            var sessionHelper = new SessionStorageHelper();
            var sessionList = new List<Session>();
            foreach (string s in sessionIdList)
            {
                var sessionKeys = TableStorageHelper.ParseCompleteKey(s);

                try
                {
                    var session = sessionHelper.Retrieve(sessionKeys["region"], sessionKeys["id"]);
                    sessionList.Add(session);
                }
                catch (DataServiceQueryException)
                { }
            }

            return sessionList;
        }

        public void Upsert()
        {
            //null e-tag - upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, this, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(this);
                _serviceContext.AttachTo(_tableName, this, null);
            }

            if (this.PartitionKey != null && this.RowKey != null)
            {
                _serviceContext.UpdateObject(this);
            }
            else
            {
                throw new InvalidOperationException("The current instance of" +
                    "BreakThereNowStorageHelper has a NULL value for either the PartitionKey" +
                    "propert, the RowKey property, or both.");
            }

            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();

            var relatedObjectKeys = TableStorageHelper.ParseCompleteKey(PartitionKey);
            if (relatedObjectKeys["type"] == "Surfer")
            {
                var thereNowHelper = new ThereNowStorageHelper();
                thereNowHelper.PartitionKey = RowKey;
                thereNowHelper.RowKey = PartitionKey;
                thereNowHelper.Upsert();
            }
        }

        public void Delete()
        {
            _serviceContext.AttachTo(_tableName, this, "*");
            _serviceContext.DeleteObject(this);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
