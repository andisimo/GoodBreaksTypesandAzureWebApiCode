﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using System.Net.Http;
using System.Net;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfSurfersController : ApiController
    {
        public List<Surfer> Get(string relatedObjectCompleteKey)
        {
            var thereNowHelper = new ThereNowStorageHelper();
            var surferList = thereNowHelper.RetrieveSurfersThereNow(relatedObjectCompleteKey);

            return surferList;
        }

        //Add surfer to Break.ThereNow or Session.SurfersAtSession
        public HttpResponseMessage Post([FromUri] string surferCompleteKey, string sessionOrBreakCompleteKey)
        {
            Dictionary<string, string> surferKeys = TableStorageHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> sessionOrBreakKeys = TableStorageHelper.ParseCompleteKey(sessionOrBreakCompleteKey);

            var thereNowHelper = new ThereNowStorageHelper();
            thereNowHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(sessionOrBreakKeys["region"], sessionOrBreakKeys["id"]);
            thereNowHelper.RowKey = TableStorageHelper.ConstructCompleteKey(surferKeys["region"], surferKeys["id"]);
            thereNowHelper.Upsert();

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        //Remove surfer from Break.ThereNow or Session.SurfersAtSession - although the latter should not be done
        public HttpResponseMessage Delete([FromUri] string surferCompleteKey, string sessionOrBreakCompleteKey)
        {
            Dictionary<string, string> surferKeys = TableStorageHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> sessionOrBreakKeys = TableStorageHelper.ParseCompleteKey(sessionOrBreakCompleteKey);

            var thereNowHelper = new ThereNowStorageHelper();
            thereNowHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(sessionOrBreakKeys["region"], sessionOrBreakKeys["id"]);
            thereNowHelper.RowKey = TableStorageHelper.ConstructCompleteKey(surferKeys["region"], surferKeys["id"]);
            thereNowHelper.Delete();

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
