﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace GoodBreaksTypes
{
    public class SortedCommentList 
    {
        //fields
        private List<Comment> _comments = new List<Comment>(); 

        //properties
        public ObservableCollection<Comment> Comments
        {
            get
            {
                _comments.Sort(
                    (comment1, comment2) => comment1.Timestamp.CompareTo(comment2.Timestamp));

                return _comments;
            } 
            
            set
            {
                List<Comment> stagingCollection = new List<Comment>();
                stagingCollection.AddRange(value);
                _comments = stagingCollection;
            }
        }

        //constructors
        public SortedCommentList()
        {
                
        }

        public SortedCommentList(ICollection<Comment> comments)
        {
            _comments = comments as List<Comment>;
        }

        //methods
        public void Add(Comment comment)
        {
            _comments.Add(comment);
        }
    }
}
