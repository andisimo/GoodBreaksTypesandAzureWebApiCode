package GoodBreaksTypes;

// ********* THIS FILE IS AUTO PORTED FROM C# USING CODEPORTING.COM *********



public interface ICommentable
{
    //properties
    public String getName(); public void setName(String value);
    public String getPartitionKey(); public void setPartitionKey(String value);
    public String getRowKey(); public void setRowKey(String value);
    public SortedCommentList getCommentsAboutMe(); public void setCommentsAboutMe(SortedCommentList value);

    //methods
    public void addComment(Comment comment);
}

