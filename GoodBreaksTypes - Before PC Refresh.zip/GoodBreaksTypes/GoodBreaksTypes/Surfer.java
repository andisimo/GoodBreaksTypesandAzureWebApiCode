package GoodBreaksTypes;

// ********* THIS FILE IS AUTO PORTED FROM C# USING CODEPORTING.COM *********

import com.codeporting.csharp2java.ms;
import com.codeporting.csharp2java.java.Event;
import java.util.ArrayList;
import java.util.Collection;
import com.codeporting.csharp2java.System.Guid;
import PropertyChangedEventArgs;


@DataServiceKey ("PartitionKey", "RowKey")
public class Surfer extends ICommentable
{
    //fields
    private ArrayList< Surfer> _buddies = new ArrayList< Surfer>();
    private ArrayList<SurfBoard> _surfBoards = new ArrayList<SurfBoard>();
    private ArrayList<Session> _sessions = new ArrayList<Session>();
    private SortedCommentList _commentsAboutMe = new SortedCommentList();
    private SortedCommentList _commentsByMe = new SortedCommentList();
    private ArrayList<Break> _breaks = new ArrayList<Break>();

    //properties
     String _PartitionKey;public String getPartitionKey(){ return _PartitionKey; }; public void setPartitionKey(String value){_PartitionKey = value; };
     String _RowKey;public String getRowKey(){ return _RowKey; }; public void setRowKey(String value){_RowKey = value; };
     String _FirstName;public String getFirstName(){ return _FirstName; }; public void setFirstName(String value){_FirstName = value; };
     String _LastName;public String getLastName(){ return _LastName; }; public void setLastName(String value){_LastName = value; };
     String _NickName;public String getNickName(){ return _NickName; }; public void setNickName(String value){_NickName = value; };
     String _Name;public String getName(){ return _Name; }; public void setName(String value){_Name = value; };
     String _Description;public String getDescription(){ return _Description; }; public void setDescription(String value){_Description = value; };
     String _ImageLocation;public String getImageLocation(){ return _ImageLocation; }; public void setImageLocation(String value){_ImageLocation = value; };
     String _Region;public String getRegion(){ return _Region; }; public void setRegion(String value){_Region = value; };

    //collection properties
    @JsonIgnore
    public Collection< Surfer> getBuddies() { return _buddies; }
    @JsonIgnore
    public void setBuddies(Collection< Surfer> value) { _buddies = ms.as(value, ArrayList< Surfer>.class); }
    
    @JsonIgnore
    public Collection<SurfBoard> getSurfBoards() { return _surfBoards; }
    @JsonIgnore
    public void setSurfBoards(Collection<SurfBoard> value) { _surfBoards = ms.as(value, ArrayList<SurfBoard>.class); }

    @JsonIgnore
    public Collection<Session> getSessions() { return _sessions; }
    @JsonIgnore
    public void setSessions(Collection<Session> value) { _sessions = ms.as(value, ArrayList<Session>.class); }

    @JsonIgnore
    public SortedCommentList getCommentsAboutMe() { return _commentsAboutMe; }
    @JsonIgnore
    public void setCommentsAboutMe(SortedCommentList value)
    {
        if (_commentsAboutMe != value)
        {
            _commentsAboutMe = value;
            notifyPropertyChanged("CommentsAboutMe");
        }
    }

    @JsonIgnore
    public SortedCommentList getCommentsByMe() { return _commentsByMe; }
    @JsonIgnore
    public void setCommentsByMe(SortedCommentList value)
    {
        if (_commentsByMe != value)
        {
            _commentsByMe = value;
            notifyPropertyChanged("CommentsByMe");
        }
    }

    @JsonIgnore
    public Collection<Break> getBreaks() { return _breaks; }
    @JsonIgnore
    public void setBreaks(Collection<Break> value)
    {
        if (_breaks != value)
        {
            _breaks = ms.as(value, ArrayList<Break>.class);
            notifyPropertyChanged("Breaks");
        }
    }

    //constructors
    public Surfer()
    { }

    public Surfer(String surferFirstName, String surferLastName, String surferRegion)
    {
        setFirstName(surferFirstName);
        setLastName(surferLastName);
        setName(com.codeporting.csharp2java.System.msString.concat(surferFirstName,  " ",  surferLastName));
        setRegion(surferRegion);
        setPartitionKey(getRegion());
        setRowKey(com.codeporting.csharp2java.System.msString.concat("sur-",  Guid.newGuid().toString()));
    }

    //methods
    public void addBuddy(Surfer surfer)
    {
        getBuddies().add(surfer);
    }

    public void addBoard(SurfBoard board)
    {
        getSurfBoards().add(board);
    }

    public void removeBoard(SurfBoard board)
    {
        getSurfBoards().remove(board); 
    }

    public void joinSession(Session sessionToJoin)
    {
        getSessions().add(sessionToJoin);
        sessionToJoin.AddSurfer(this); 
    }

    public void undoJoindSession(Session sessionToUndoJoin)
    {
        getSessions().remove(sessionToUndoJoin);
        sessionToUndoJoin.RemoveSurfer(this); 
    }

    public void addComment(Comment comment)
    {
        getCommentsAboutMe().Comments.Add(comment);
    }

    //INofityPropertyChanged Implementation
    private PropertyChangedEventHandler PropertyChangedDelegate;

    //INofityPropertyChanged Implementation
    public final Event<PropertyChangedEventHandler> PropertyChanged= new Event<PropertyChangedEventHandler>() {{

    //INofityPropertyChanged Implementation
    PropertyChangedDelegate =  new PropertyChangedEventHandler() {
	public void invoke() {
		for (PropertyChangedEventHandler delegate : invocationList) delegate.invoke();
	}};
	}};
    
	private void notifyPropertyChanged(String propertyName)
    {
        PropertyChangedEventHandler handler = PropertyChangedDelegate;
        if (null != handler)
        {
            handler.invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

