package GoodBreaksTypes;

// ********* THIS FILE IS AUTO PORTED FROM C# USING CODEPORTING.COM *********

import com.codeporting.csharp2java.java.Event;
import java.util.Collection;
import java.util.ArrayList;
import com.codeporting.csharp2java.System.Guid;
import PropertyChangedEventArgs;


@DataServiceKey ("PartitionKey", "RowKey")
public class Break extends ICommentable implements INotifyPropertyChanged
{
    //fields
    private SortedCommentList _commentsAboutMe = new SortedCommentList();
    private Collection<Surfer> _thereNow = new ArrayList<Surfer>();
    private String _region;

    //properties
     String _PartitionKey;public String getPartitionKey(){ return _PartitionKey; }; public void setPartitionKey(String value){_PartitionKey = value; };
     String _RowKey;public String getRowKey(){ return _RowKey; }; public void setRowKey(String value){_RowKey = value; };
     String _Name;public String getName(){ return _Name; }; public void setName(String value){_Name = value; };
     double _Latitude;public double getLatitude(){ return _Latitude; }; public void setLatitude(double value){_Latitude = value; };
     double _Longitude;public double getLongitude(){ return _Longitude; }; public void setLongitude(double value){_Longitude = value; };

    public String getRegion()
    {
        return _region;
    }
    public void setRegion(String value)
    {
        _region = value;
        setPartitionKey(value);
    }

    @JsonIgnore
    public SortedCommentList getCommentsAboutMe() { return _commentsAboutMe; }
    @JsonIgnore
    public void setCommentsAboutMe(SortedCommentList value) 
    {
        if (_commentsAboutMe != value)
        {
            _commentsAboutMe = value;
            notifyPropertyChanged("CommentsAboutMe");
        }
    }

    @JsonIgnore
    public Collection<Surfer> getThereNow() { return _thereNow; }
    @JsonIgnore
    public void setThereNow(Collection<Surfer> value)
    {
        if (_thereNow != value)
        {
            _thereNow = value;
            notifyPropertyChanged("ThereNow");
        }
    }

    //Constructors
    public Break()
    { }
    public Break(String breakName, double locLatitude, double locLongitude, String region)
    {
        setName(breakName);
        setLatitude(locLatitude);
        setLongitude(locLongitude);
        setRegion(region);
        setRowKey(com.codeporting.csharp2java.System.msString.concat("bre-",  Guid.newGuid().toString()));
    }

    //Methods
    public void addComment(Comment comment)
    {
        getCommentsAboutMe().Add(comment);
    }

    //INofityPropertyChanged Implementation
    private PropertyChangedEventHandler PropertyChangedDelegate;

    //INofityPropertyChanged Implementation
    public final Event<PropertyChangedEventHandler> PropertyChanged= new Event<PropertyChangedEventHandler>() {{

    //INofityPropertyChanged Implementation
    PropertyChangedDelegate =  new PropertyChangedEventHandler() {
public void invoke() {
for (PropertyChangedEventHandler delegate : invocationList) delegate.invoke();
}};
}};
    private void notifyPropertyChanged(String propertyName)
    {
        PropertyChangedEventHandler handler = PropertyChangedDelegate;
        if (null != handler)
        {
            handler.invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

