package GoodBreaksTypes;

// ********* THIS FILE IS AUTO PORTED FROM C# USING CODEPORTING.COM *********

import com.codeporting.csharp2java.System.DateTime;
import com.codeporting.csharp2java.System.Guid;


@DataServiceKey ("PartitionKey", "RowKey")
public class Comment
{

    //properties
     String _PartitionKey;public String getPartitionKey(){ return _PartitionKey; }; public void setPartitionKey(String value){_PartitionKey = value; };
     String _RowKey;public String getRowKey(){ return _RowKey; }; public void setRowKey(String value){_RowKey = value; };
     String _AboutKey;public String getAboutKey(){ return _AboutKey; }; public void setAboutKey(String value){_AboutKey = value; };
     String _FromSurferKey;public String getFromSurferKey(){ return _FromSurferKey; }; public void setFromSurferKey(String value){_FromSurferKey = value; };
     String _CommentText;public String getCommentText(){ return _CommentText; }; public void setCommentText(String value){_CommentText = value; };
     Surfer _FromSurfer;public Surfer getFromSurfer(){ return _FromSurfer; }; public void setFromSurfer(Surfer value){_FromSurfer = value; };
     ICommentable _About;public ICommentable getAbout(){ return _About; }; public void setAbout(ICommentable value){_About = value; };
     DateTime _CommentDateTime;public DateTime getCommentDateTime(){ return _CommentDateTime; }; public void setCommentDateTime(DateTime value){_CommentDateTime = value; };

    //constructors
    public Comment()
    { }

    public Comment(String text, Surfer fromSurfer, ICommentable commentAbout)
    {
        setCommentText(text);
        setCommentDateTime(DateTime.UtcNow.Clone());
        setFromSurfer(fromSurfer);
        getFromSurfer().CommentsByMe.Add(this);
        setAbout(commentAbout);
        commentAbout.AddComment(this);
        setAboutKey(KeyBuilder.BuildAboutKey(this, getAbout()));
        setFromSurferKey(KeyBuilder.BuildFromKey(fromSurfer));
        setPartitionKey(getFromSurfer().PartitionKey);
        setRowKey(com.codeporting.csharp2java.System.msString.concat("com-",  Guid.newGuid().toString()));
    }
}

