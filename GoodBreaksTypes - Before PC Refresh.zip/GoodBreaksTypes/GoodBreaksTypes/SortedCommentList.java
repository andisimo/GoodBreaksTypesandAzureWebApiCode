package GoodBreaksTypes;

// ********* THIS FILE IS AUTO PORTED FROM C# USING CODEPORTING.COM *********

import com.codeporting.csharp2java.ms;
import java.util.ArrayList;
import java.util.Collection;


public class SortedCommentList 
{
    //fields
    private ArrayList<Comment> _comments = new ArrayList<Comment>(); 

    //properties
    public Collection<Comment> getComments()
    {
        _comments.Sort(
            (comment1,comment2) => comment1.CommentDateTime.CompareTo(comment2.CommentDateTime));

        return _comments;
    } 
    
    public void setComments(Collection<Comment> value)
    {
        ArrayList<Comment> stagingCollection = new ArrayList<Comment>();
        stagingCollection.addRange(value);
        _comments = stagingCollection;
    }

    //constructors
    public SortedCommentList()
    {
            
    }

    public SortedCommentList(Collection<Comment> comments)
    {
        _comments = ms.as(comments, ArrayList<Comment>.class);
    }

    //methods
    public void add(Comment comment)
    {
        _comments.add(comment);
    }
}

