﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class BreakCommentsController : ApiController
    {
        public List<Comment> Get(string breakPK, string breakRK)
        {
            var helper = new BreakStorageHelper();
            var commentList = helper.RetrieveCommentsAboutMe(breakPK, breakRK);

            return commentList;
        }
    }
}
