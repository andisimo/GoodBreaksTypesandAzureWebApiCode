﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class TableStorageHelper 
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;

        //private members
        private int _highestCommentIndex;
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //Constructor
        public TableStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public dynamic Retrieve(string typeName, string partitionKey, string rowKey)
        {
            string _tableName = GetTableNameForType(typeName);
            dynamic entity; 

            switch (typeName)
            {
                case "Surfer":
                    entity =
                        (from getThis in _serviceContext.CreateQuery<Surfer>(_tableName)
                        where getThis.PartitionKey == partitionKey &&
                        getThis.RowKey == rowKey
                        select getThis).FirstOrDefault();
                    break;
                case "Break":
                    entity =
                        (from getThis in _serviceContext.CreateQuery<Break>(_tableName)
                         where getThis.PartitionKey == partitionKey &&
                         getThis.RowKey == rowKey
                         select getThis).FirstOrDefault();
                    break;
                case "Session":
                    entity =
                        (from getThis in _serviceContext.CreateQuery<Session>(_tableName)
                         where getThis.PartitionKey == partitionKey &&
                         getThis.RowKey == rowKey
                         select getThis).FirstOrDefault();
                    break;
                default:
                    throw new DataServiceQueryException("Type not recognized by TableServiceHelper.Retrieve method");
            }

            return entity;
        }

        public void Save(string tableName, dynamic itemToSave)
        {
            _serviceContext.AddObject(tableName, itemToSave); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(dynamic itemToSave)
        {
            _serviceContext.UpdateObject(itemToSave);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(string tableName, dynamic itemToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(tableName, itemToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(itemToSave);
                _serviceContext.AttachTo(tableName, itemToSave, null);
            }

            _serviceContext.UpdateObject(itemToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace)  
            _serviceContext.SaveChanges();
        }

        public void Delete(string tableName, dynamic itemToDelete)
        {
            _serviceContext.DeleteObject(itemToDelete);
        }

        public string GetTableNameForType(string typeName)
        {
            string _tableName = "";

            switch (typeName)
            {
                case "Surfer":
                    _tableName = "SurfersComments";
                    break;
                case "Comment":
                    _tableName = "SurfersComments";
                    break;
                case "Break":
                    _tableName = "SessionsBreaks";
                    break;
                case "Session":
                    _tableName = "SessionsBreaks";
                    break;
                case "BreakThereNowStorageHelper":
                    _tableName = "ThereNow";
                    break;
                default:
                    throw new DataServiceQueryException("The type " + typeName
                        + " is not recognized by the TableStorageHelper.GetTableNameForType method.");
            }

            return _tableName;
        }

        public static Dictionary<string, string> ParseCompleteKey(string completeKey)
        {
            //example:
            //USWC|bre-28197a6a-f12d-4fdb-a87d-4abaa731437f
            //names of values returned: "type", "id", "region"

            var returnPairs = new Dictionary<string, string>();

            int bar = completeKey.IndexOf("|");
            int guidStart = completeKey.IndexOf("-") + 1;
            
            var region = completeKey.Substring(0, bar);
            returnPairs.Add("region", region);

            var type = completeKey.Substring(bar+1, (guidStart-1) - (bar+1));
            switch (type)
            {
                case "sur":
                    type = "Surfer";
                    break;
                case "ses":
                    type = "Session";
                    break;
                case "bre":
                    type = "Break";
                    break;
                case "com":
                    type = "Comment";
                    break;
                case "boa":
                    type = "SurfBoard";
                    break;
            }
            returnPairs.Add("type", type);

            var id = completeKey.Substring(bar + 1);
            returnPairs.Add("id", id);

            return returnPairs;
        }

        public static string ConstructCompleteKey(string partitionKey, string rowKey)
        {
            if (partitionKey != null && partitionKey != "" && rowKey != null && rowKey != "")
            {
                string completeKey = partitionKey + "|" + rowKey;
                return completeKey;
            }
            else
            {
                throw new ArgumentNullException("partitionKey or rowKey",
                   "The partitionKey or rowKey argument was" +
                   "NULL or blank for the TableStorageHelper.ConstructCompleteKey method." +
                   "NULL or blank values are not permitted.");
            } 
        }

        public void AddToCommentsAboutMe(dynamic itemToUpdate, Comment comment)
        {
            EventHandler<ReadingWritingEntityEventArgs> readingCommentsDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                _highestCommentIndex = 0;
                var propertyNode = e.Data.Descendants(_m + "properties").First();
                var properties = propertyNode.DescendantNodes();
                foreach (XNode node in properties)
                {
                    XElement element = node as XElement;
                    if (element != null)
                    {
                        string name = element.Name.ToString();

                        if (name.Contains("CommentsAboutMe"))
                        {
                            int int1 = name.IndexOf("CommentsAboutMe_");
                            string string1 = name.Substring(int1 + 16);
                            int index = Int32.Parse(string1);
                            if (index > _highestCommentIndex)
                                _highestCommentIndex = index;
                        }
                    }
                }
            };
            _serviceContext.ReadingEntity += readingCommentsDelegate;

            EventHandler<ReadingWritingEntityEventArgs> writingCommentsDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                XElement properties;
                ICommentable commentAbout = e.Entity as ICommentable;

                if (commentAbout != null)
                {
                    List<Comment> commentsAbout = commentAbout.CommentsAboutMe.Comments.ToList<Comment>();
                    foreach (Comment c in commentsAbout)
                    {
                        _highestCommentIndex++;
                        XElement propertyToAdd = new XElement(_d + "CommentsAboutMe_" + _highestCommentIndex.ToString(), c.PartitionKey + "|" + c.RowKey);
                        properties = e.Data.Descendants(_m + "properties").First();
                        properties.Add(propertyToAdd);
                    }
                }
            };
            _serviceContext.WritingEntity += writingCommentsDelegate;

            ICommentable objectToCountProps;
            string partitionKey = itemToUpdate.PartitionKey;
            string rowKey = itemToUpdate.RowKey;

            Type type = itemToUpdate.GetType();
            switch (type.Name)
            {
                case "Surfer":
                    objectToCountProps =
                        (from getThis in _serviceContext.CreateQuery<Surfer>("SurfersComments")
                         where getThis.PartitionKey == partitionKey &&
                         getThis.RowKey == rowKey
                         select getThis).FirstOrDefault();
                    break;
                case "Break":
                    objectToCountProps =
                        (from getThis in _serviceContext.CreateQuery<Break>("SessionsBreaks")
                         where getThis.PartitionKey == partitionKey &&
                         getThis.RowKey == rowKey
                         select getThis).FirstOrDefault();
                    break;
                case "Session":
                    objectToCountProps =
                        (from getThis in _serviceContext.CreateQuery<Session>("SessionsBreaks")
                         where getThis.PartitionKey == partitionKey &&
                         getThis.RowKey == rowKey
                         select getThis).FirstOrDefault();
                    break;
                default:
                    throw new DataServiceQueryException("Type not recognized by TableServiceHelper.UpdateCommentsAbout method");
            }


            objectToCountProps.CommentsAboutMe.Comments.Clear();
            objectToCountProps.CommentsAboutMe.Add(comment);

            Upsert(GetTableNameForType(objectToCountProps.GetType().Name), objectToCountProps);

            _serviceContext.ReadingEntity -= readingCommentsDelegate;
            _serviceContext.WritingEntity -= writingCommentsDelegate;
        }
    }
}