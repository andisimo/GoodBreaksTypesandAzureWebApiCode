﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class CollectionOfBreaksController : ApiController
    {
        public List<Break> Get(string relatedObjectPK, string relatedObjectRK)
        {
            var helper = new BreakCollectionStorageHelper();
            var breakList = helper.RetrieveBreaks(
                TableStorageHelper.ConstructCompleteKey(relatedObjectPK, relatedObjectRK));

            return breakList;
        }
    }
}