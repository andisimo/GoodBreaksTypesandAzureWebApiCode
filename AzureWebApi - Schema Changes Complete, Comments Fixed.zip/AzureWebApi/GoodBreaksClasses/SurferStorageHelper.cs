﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SurferStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SurfersComments";

        //Constructor
        public SurferStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Surfer Retrieve(string partitionKey, string rowKey)
        {
            Surfer surfer =
                (from getThis in _serviceContext.CreateQuery<Surfer>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return surfer;
        }

        public void Save(Surfer surfer)
        {
            _serviceContext.AddObject(_tableName, surfer); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(Surfer surfer)
        {
            _serviceContext.UpdateObject(surfer);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Surfer surferToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToSave);
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }

            _serviceContext.UpdateObject(surferToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Surfer surferToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToDelete);
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }

            _serviceContext.DeleteObject(surferToDelete);
            _serviceContext.SaveChangesWithRetries();

            DeleteAllTraces(surferToDelete);
        }

        private void DeleteAllTraces(Surfer deletedSurfer)
        {

        }
    }
}
