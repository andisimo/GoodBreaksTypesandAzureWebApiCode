﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SurferStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SurfersComments";
        

        //private fields
        private int _totalBuddies;
        private int _totalSessions;
        private int _highestCommentIndex;
        private XNamespace _d = "http://schemas.microsoft.com/ado/2007/08/dataservices";
        private XNamespace _m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";

        //Constructor
        public SurferStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Surfer Retrieve(string partitionKey, string rowKey)
        {
            Surfer surfer =
                (from getThis in _serviceContext.CreateQuery<Surfer>(_tableName)
                 where getThis.PartitionKey == partitionKey &&
                 getThis.RowKey == rowKey
                 select getThis).FirstOrDefault();

            return surfer;
        }

        public List<Surfer> RetrieveBuddies(string partitionKey, string rowKey)
        {
            var buddyIdList = new List<string>();

            EventHandler<ReadingWritingEntityEventArgs> readingBuddiesDelegate2 = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                var propertyNode = e.Data.Descendants(_m + "properties").First();
                var properties = propertyNode.DescendantNodes();
                foreach (XNode node in properties)
                {
                    XElement element = node as XElement;
                    if (element != null)
                    {
                        string name = element.Name.ToString();
                        
                        if (name.Contains("Buddies"))
                        {
                            buddyIdList.Add(element.Value);
                        }
                    }
                }
            };
            _serviceContext.ReadingEntity += readingBuddiesDelegate2;
            Surfer surfer = Retrieve(partitionKey, rowKey);
            _serviceContext.ReadingEntity -= readingBuddiesDelegate2;

            var buddyList = new List<Surfer>();
            var tableHelper = new TableStorageHelper();
            foreach (string buddyId in buddyIdList)
            {
                var buddyKeys = tableHelper.ParseCompleteKey(buddyId);
                var buddy = Retrieve(buddyKeys["region"], buddyKeys["id"]);
                buddyList.Add(buddy);
            }

            return buddyList;
        }

        public void Save(Surfer surfer)
        {
            _serviceContext.AddObject(_tableName, surfer); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(Surfer surfer)
        {
            _serviceContext.UpdateObject(surfer);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Surfer surferToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToSave);
                _serviceContext.AttachTo(_tableName, surferToSave, null);
            }

            _serviceContext.UpdateObject(surferToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Surfer surferToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(surferToDelete);
                _serviceContext.AttachTo(_tableName, surferToDelete, "*");
            }

            _serviceContext.DeleteObject(surferToDelete);
            _serviceContext.SaveChangesWithRetries();
        }

        public void AddBuddyToCollection(string surferPK, string surferRK, string buddyPK, string buddyRK)
        {
            EventHandler<ReadingWritingEntityEventArgs> readingBuddiesDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                _totalBuddies = 0;
                var propertyNode = e.Data.Descendants(_m + "properties").First();
                var properties = propertyNode.DescendantNodes();
                foreach (XNode node in properties)
                {
                    XElement element = node as XElement;
                    if (element != null)
                    {
                        string name = element.Name.ToString();

                        if (name.Contains("Buddies"))
                        {
                            int index = Int32.Parse(name.Substring(name.IndexOf("Buddies_") + 8));
                            if (index > _totalBuddies)
                                _totalBuddies = index;
                        }
                    }
                }
            };
            _serviceContext.ReadingEntity += readingBuddiesDelegate;

            EventHandler<ReadingWritingEntityEventArgs> writingBuddiesDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                XElement properties;
                var surfer = e.Entity as Surfer;

                if (surfer != null)
                {
                    var buddies = surfer.Buddies.ToList<Surfer>();
                    foreach (Surfer s in buddies)
                    {
                        _totalBuddies++;
                        XElement propertyToAdd = new XElement(_d + "Buddies_" + _totalBuddies.ToString(), s.PartitionKey + "|" + s.RowKey);
                        properties = e.Data.Descendants(_m + "properties").First();
                        properties.Add(propertyToAdd);
                    }
                }
            };
            _serviceContext.WritingEntity += writingBuddiesDelegate;

            var surferFromStorage = Retrieve(partitionKey: surferPK, rowKey: surferRK);
            var buddy = Retrieve(partitionKey: buddyPK, rowKey: buddyRK);

            surferFromStorage.Buddies.Clear();
            surferFromStorage.AddBuddy(buddy);

            Update(surferFromStorage);
            _serviceContext.ReadingEntity -= readingBuddiesDelegate;
            _serviceContext.WritingEntity -= writingBuddiesDelegate;
        }

        public void AddToCommentsByMe(Surfer surferToUpdate, Comment comment)
        {
            EventHandler<ReadingWritingEntityEventArgs> readingCommentsDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                _highestCommentIndex = 0;
                var propertyNode = e.Data.Descendants(_m + "properties").First();
                var properties = propertyNode.DescendantNodes();
                foreach (XNode node in properties)
                {
                    XElement element = node as XElement;
                    if (element != null)
                    {
                        string name = element.Name.ToString();

                        if (name.Contains("CommentsByMe"))
                        {
                            int int1 = name.IndexOf("CommentsByMe_");
                            string string1 = name.Substring(int1 + 13);
                            int index = Int32.Parse(string1);
                            if (index > _highestCommentIndex)
                                _highestCommentIndex = index;
                        }
                    }
                }
            };
            _serviceContext.ReadingEntity += readingCommentsDelegate;

            EventHandler<ReadingWritingEntityEventArgs> writingCommentsDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                XElement properties;
                Surfer commentFrom = e.Entity as Surfer;

                if (commentFrom != null)
                {
                    List<Comment> commentsFrom = commentFrom.CommentsByMe.Comments.ToList<Comment>();
                    foreach (Comment c in commentsFrom)
                    {
                        _highestCommentIndex++;
                        XElement propertyToAdd = new XElement(_d + "CommentsByMe_" + _highestCommentIndex.ToString(), c.PartitionKey + "|" + c.RowKey);
                        properties = e.Data.Descendants(_m + "properties").First();
                        properties.Add(propertyToAdd);
                    }
                }
            };
            _serviceContext.WritingEntity += writingCommentsDelegate;

            Surfer commentingSurfer =
                (from surfer in _serviceContext.CreateQuery<Surfer>("SurfersComments")
                 where surfer.PartitionKey == surferToUpdate.PartitionKey &&
                 surfer.RowKey == surferToUpdate.RowKey
                 select surfer).FirstOrDefault();
            commentingSurfer.CommentsByMe.Comments.Clear();
            commentingSurfer.CommentsByMe.Add(comment);
            Upsert(commentingSurfer);

            _serviceContext.ReadingEntity -= readingCommentsDelegate;
            _serviceContext.WritingEntity -= writingCommentsDelegate;
        }

        public void AddSessionToCollection(string surferPK, string surferRK, string sessionPK, string sessionRK)
        {
            EventHandler<ReadingWritingEntityEventArgs> readingSessionsDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                _totalSessions = 0;
                var propertyNode = e.Data.Descendants(_m + "properties").First();
                var properties = propertyNode.DescendantNodes();
                foreach (XNode node in properties)
                {
                    XElement element = node as XElement;
                    if (element != null)
                    {
                        string name = element.Name.ToString();

                        if (name.Contains("Sessions"))
                        {
                            int index = Int32.Parse(name.Substring(name.IndexOf("Sessions_") + 9));
                            if (index > _totalSessions)
                                _totalSessions = index;
                        }
                    }
                }
            };
            _serviceContext.ReadingEntity += readingSessionsDelegate;

            EventHandler<ReadingWritingEntityEventArgs> writingSessionsDelegate = delegate(object sender, ReadingWritingEntityEventArgs e)
            {
                XElement properties;
                var surfer = e.Entity as Surfer;

                if (surfer != null)
                {
                    var sessions = surfer.Sessions.ToList<Session>();
                    foreach (Session s in sessions)
                    {
                        _totalSessions++;
                        XElement propertyToAdd = new XElement(_d + "Sessions_" + _totalSessions.ToString(), s.PartitionKey + "|" + s.RowKey);
                        properties = e.Data.Descendants(_m + "properties").First();
                        properties.Add(propertyToAdd);
                    }
                }
            };
            _serviceContext.WritingEntity += writingSessionsDelegate;

            var surferFromStorage = Retrieve(partitionKey: surferPK, rowKey: surferRK);

            var helper = new SessionStorageHelper();
            var session = helper.Retrieve(sessionPK, sessionRK);

            surferFromStorage.Sessions.Clear();
            surferFromStorage.Sessions.Add(session);

            Update(surferFromStorage);
            _serviceContext.ReadingEntity -= readingSessionsDelegate;
            _serviceContext.WritingEntity -= writingSessionsDelegate;
        }
    }
}
