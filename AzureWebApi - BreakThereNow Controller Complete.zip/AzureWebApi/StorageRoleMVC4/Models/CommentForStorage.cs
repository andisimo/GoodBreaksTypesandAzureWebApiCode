﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services.Common;

namespace GoodBreaksClasses
{
    internal class CommentForStorage : Comment
    {
        //private members
        private TableStorageHelper<Comment> _helper = new TableStorageHelper<Comment>();
        private string _tableName = "SurfersComments";
        private string _aboutTypeName;

        //constructors
        
        public CommentForStorage(Comment comment)
        {
            PartitionKey = comment.PartitionKey;
            RowKey = comment.RowKey;
            CommentDateTime = comment.CommentDateTime;
            CommentText = comment.CommentText;
            FromSurfer = comment.FromSurfer;
            FromSurferKey = BuildFromKey(comment.FromSurfer);
            About = comment.About;
            _aboutTypeName = comment.AboutType.Name;
            AboutKey = BuildAboutKey(comment: comment, typeName: _aboutTypeName);
        }

        //methods
        internal void SaveComment()
        {
            _helper.Save(_tableName, this);
            UpdateEntityAbout();
        }

        private string BuildAboutKey(Comment comment, string typeName)
        {
            string aboutKey = "";
            string aboutTable;

            switch (typeName)
            {
                case "Surfer":
                    aboutTable = "SurfersComments";
                    Surfer AboutSurfer = comment.About as Surfer;
                    aboutKey = aboutTable + "&" + AboutSurfer.Region + "&" + AboutSurfer.RowKey;
                    break;

                case "Break":
                    aboutTable = "SessionsBreaks";
                    Break AboutBreak = comment.About as Break;
                    aboutKey = aboutTable + "&" + AboutBreak.Region + "&" + AboutBreak.RowKey;
                    break;

                case "Session":
                    aboutTable= "SessionsBreaks";
                    Session AboutSession = comment.About as Session;
                    aboutKey = aboutTable + "&" + AboutSession.Region + "&" + AboutSession.RowKey;
                    break;
            }

            if (aboutKey != "")
            {
                return aboutKey;
            }
            else
            {
                throw new Exception("The comment's AboutKey could not be found.");
            }
        }

        private string BuildFromKey(Surfer surfer)
        {
            return _tableName + "&" + surfer.Region + "&" + surfer.RowKey;
        }

        private void UpdateEntityAbout()
        {
            switch (_aboutTypeName)
            {
                case "Surfer":
                    //SurferForStorage aboutSurfer = new SurferForStorage();
                    //aboutSurfer.PartitionKey = ((Surfer)About).PartitionKey;
                    //aboutSurfer.RowKey = ((Surfer)About).RowKey;
                    //aboutSurfer.CommentsAboutMe.Add(this);

                    //aboutSurfer.UpdateCommentsAbout();
                    break;

                case "Break":
                   
                    break;

                case "Session":
                    
                    break;
            }
        }
    }
}