﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using System.Net.Http;
using System.Net;

namespace StorageRoleMVC4.Controllers
{
    public class BreakSurfersController : ApiController
    {
        public List<Surfer> Get(string breakCompleteKey)
        {
            var breakThereHelper = new BreakThereNowStorageHelper();
            var surferList = breakThereHelper.RetrieveSurfersThereNow(breakCompleteKey);

            return surferList;
        }

        //Add surfer to Break.ThereNow
        public HttpResponseMessage Post([FromUri] string surferCompleteKey, string breakCompleteKey)
        {
            var tableHelper = new TableStorageHelper();
            Dictionary<string, string> surferKeys = tableHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> breakKeys = tableHelper.ParseCompleteKey(breakCompleteKey);

            var breakHelper = new BreakStorageHelper();
            breakHelper.AddSurferToThereNow(surferKeys["region"], surferKeys["id"], breakKeys["region"], breakKeys["id"]);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        //Remove surfer from Break.ThereNow
        public HttpResponseMessage Delete([FromUri] string surferCompleteKey, string breakCompleteKey)
        {
            var tableHelper = new TableStorageHelper();
            Dictionary<string, string> surferKeys = tableHelper.ParseCompleteKey(surferCompleteKey);
            Dictionary<string, string> breakKeys = tableHelper.ParseCompleteKey(breakCompleteKey);

            var breakHelper = new BreakStorageHelper();
            breakHelper.RemoveSurferFromThereNow(surferKeys["region"], surferKeys["id"], breakKeys["region"], breakKeys["id"]);

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
