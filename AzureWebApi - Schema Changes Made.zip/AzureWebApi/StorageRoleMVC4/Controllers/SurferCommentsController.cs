﻿using System.Collections.Generic;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class SurferCommentsController : ApiController
    {
        public List<Comment> Get(string surferPK, string surferRK)
        {
            var helper = new SurferStorageHelper();
            var commentList = helper.RetrieveCommentsByMe(surferPK, surferRK);

            return commentList;
        }
    }
}
