﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;

namespace StorageRoleMVC4.Controllers
{
    public class BuddiesController : ApiController
    {
        public List<Surfer> Get(string surferPK, string surferRK)
        {
            BuddyStorageHelper buddyHelper = new BuddyStorageHelper();
            var buddyList =buddyHelper.RetrieveBuddies(
                TableStorageHelper.ConstructCompleteKey(surferPK, surferRK));
            SurferStorageHelper helper = new SurferStorageHelper();

            return buddyList;
        }

        public HttpResponseMessage Post(string surferCompleteKey, string buddyCompleteKey)
        {
            //check completeKey parameters for improper formatting
            TableStorageHelper.ParseCompleteKey(surferCompleteKey);
            TableStorageHelper.ParseCompleteKey(buddyCompleteKey);

            var buddyHelper = new BuddyStorageHelper(
                surferCompleteKey, buddyCompleteKey);
            buddyHelper.Upsert();

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        public HttpResponseMessage Delete(string surferCompleteKey, string buddyCompleteKey)
        {
            var buddyHelper = new BuddyStorageHelper(
                surferCompleteKey, buddyCompleteKey);
            buddyHelper.Delete();

            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}
