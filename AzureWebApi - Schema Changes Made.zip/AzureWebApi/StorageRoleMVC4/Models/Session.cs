﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Services.Common;

namespace GoodBreaksWP7.Models
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class Session : ICommentable, INotifyPropertyChanged 
    {
        //fields
        private List<Surfer> _surfersAtSession = new List<Surfer>();
        private SortedCommentList _commentsAboutMe; 

        //properties
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public Break SessionBreak { get; set; }
        public string Region { get; set; }

        public ICollection<Surfer> SurfersAtSession
        {
            get { return _surfersAtSession; }
            set { _surfersAtSession = value as List<Surfer>; }
        }

        public SortedCommentList CommentsAboutMe
        {
            get
            {
                return _commentsAboutMe;
            }
            set
            {
                if(_commentsAboutMe != value)
                {
                    _commentsAboutMe = value;
                    NotifyPropertyChanged("CommentsAboutMe");
                }
            }
        }

        //constructors
        public Session()
        {
 
        }
        
        //methods
        public void AddSurfer(Surfer surferToAdd)
        {
            SurfersAtSession.Add(surferToAdd);
            surferToAdd.Sessions.Add(this);
        }

        public ICollection<Surfer> RemoveSurfer(Surfer surferToRemove)
        {
            SurfersAtSession.Remove(surferToRemove);
            surferToRemove.Sessions.Remove(this); 
            return SurfersAtSession;
        }

        public void AddComment(Comment comment)
        {
            throw new NotImplementedException();
        }

        //INofityPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
