﻿using System;
using System.Collections.Generic;
using System.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class BuddyStorageHelper : TableServiceEntity, ICollectionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "Buddies";

        //constructors
        public BuddyStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                   (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        public BuddyStorageHelper(string surferCompleteKey, string buddyCompleteKey)
        {
            _storageAccount = CloudStorageAccount.Parse
               (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();

            PartitionKey = surferCompleteKey;
            RowKey = buddyCompleteKey;
        }

        //methods
        public List<Surfer> RetrieveBuddies(string surferCompleteKey)
        {
            CloudTableQuery<BuddyStorageHelper> partitionQuery =
                (from e in _serviceContext.CreateQuery<BuddyStorageHelper>(_tableName)
                 where e.PartitionKey == surferCompleteKey
                 select e).AsTableServiceQuery<BuddyStorageHelper>();

            var buddyIdList = new List<string>();
            foreach (BuddyStorageHelper b in partitionQuery)
            {
                string id = b.RowKey;
                buddyIdList.Add(id);
            }

            var surferHelper = new SurferStorageHelper();
            var buddyList = new List<Surfer>();
            foreach (string s in buddyIdList)
            {
                var completeKey = TableStorageHelper.ParseCompleteKey(s);
                var surfer = surferHelper.Retrieve(completeKey["region"], completeKey["id"]);
                buddyList.Add(surfer);
            }

            return buddyList;
        }

        
        public void Upsert()
        {
            //null e-tag - upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, this, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(this);
                _serviceContext.AttachTo(_tableName, this, null);
            }

            if (this.PartitionKey != null && this.RowKey != null)
            {
                _serviceContext.UpdateObject(this);
            }
            else
            {
                throw new InvalidOperationException("The current instance of" +
                    "BreakThereNowStorageHelper has a NULL value for either the PartitionKey" +
                    "propert, the RowKey property, or both.");
            }

            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete()
        {
            _serviceContext.AttachTo(_tableName, this, "*");
            _serviceContext.DeleteObject(this);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
