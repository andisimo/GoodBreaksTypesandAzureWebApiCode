﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksTypes;
using GoodBreaksClasses;

namespace StorageRoleMVC4.Controllers
{
    public class SampleDataController : ApiController
    {
        public void Get(string tableName)
        {
            var helper = new TableStorageHelper();
            helper._tableClient.DeleteTableIfExist(tableName);
        }

        public void Get(string tableName, string dummy)
        {
            var helper = new TableStorageHelper();
            helper._tableClient.CreateTableIfNotExist(tableName);
        }

        [Authorize]
        public void get(int i)
        {
            var helper = new SurferStorageHelper();
            helper.Retrieve("USWC", "sur-100");
        }

        public void get(string surferName, string breakName, string dummy)
        {
            //SURFERS
            var surfer = new Surfer("George", "Schultz", "USWC");
            surfer.RowKey = "sur-4c3261d8-3b1a-4bd4-8850-4d769cfbd7ef";
            surfer.ImageLocation = "http://farm1.staticflickr.com/16/19269665_3d92df99cc_t.jpg";
            
            var surfer2 = new Surfer("Helpga", "Schultz", "USWC");
            surfer2.RowKey = "sur-12";
            surfer2.ImageLocation = "http://farm8.staticflickr.com/7127/7606171990_3932d601ae_t.jpg";

            var surfer3 = new Surfer("Brad", "Smith", "USWC");
            surfer3.RowKey = "sur-6a3261d8-3b1a-4bd4-8850-4d769cfbd7fg";
            surfer3.ImageLocation = "http://farm1.staticflickr.com/131/357541014_0bdcf6f94d_t.jpg";

            var surfer4 = new Surfer("Kelly", "Slater", "USWC");
            surfer4.RowKey = "sur-12943028-soiue-123";
            surfer4.ImageLocation = "http://farm1.staticflickr.com/118/309935856_c370b9496b_t.jpg";

            var surfer5 = new Surfer("Noah", "Gedrich", "USEC");
            surfer5.RowKey = "sur-323";
            surfer5.ImageLocation = "http://farm5.staticflickr.com/4057/4708890950_85035f7924_t.jpg";

            var surfer6 = new Surfer("Laird", "Hamilton", "USEC");
            surfer6.RowKey = "sur-laird-123";
            surfer6.ImageLocation = "http://farm4.staticflickr.com/3086/2580414358_a909be7327_t.jpg";

            var surfer7 = new Surfer("Tony", "Biscayn", "CRWC");
            surfer7.RowKey = "sur-193elsdio8983";
            surfer7.ImageLocation = "http://farm1.staticflickr.com/132/321689818_93a23a8a73_t.jpg";

            var surfer8 = new Surfer("Antonio", "Banderas", "SPAI");
            surfer8.RowKey = "sur-323do98-swdiw-aois";
            surfer8.ImageLocation = "http://farm1.staticflickr.com/201/521878430_0d6afaad5d_t.jpg";
            
            var surferHelper = new SurferStorageHelper();
            surferHelper.Upsert(surfer);
            surferHelper.Upsert(surfer2);
            surferHelper.Upsert(surfer3);
            surferHelper.Upsert(surfer4);
            surferHelper.Upsert(surfer5);
            surferHelper.Upsert(surfer6);
            surferHelper.Upsert(surfer7);
            surferHelper.Upsert(surfer8);

            //BUDDIES
            var buddyHelper = new BuddyStorageHelper();
            buddyHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper.RowKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            buddyHelper.Upsert();

            var buddyHelper2 = new BuddyStorageHelper();
            buddyHelper2.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper2.RowKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper2.Upsert();

            var buddyHelper3 = new BuddyStorageHelper();
            buddyHelper3.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper3.RowKey = TableStorageHelper.ConstructCompleteKey(surfer4.PartitionKey, surfer4.RowKey);
            buddyHelper3.Upsert();

            var buddyHelper4 = new BuddyStorageHelper();
            buddyHelper4.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper4.RowKey = TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey);
            buddyHelper4.Upsert();

            var buddyHelper5 = new BuddyStorageHelper();
            buddyHelper5.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper5.RowKey = TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey);
            buddyHelper5.Upsert();

            var buddyHelper6 = new BuddyStorageHelper();
            buddyHelper6.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper6.RowKey = TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey);
            buddyHelper6.Upsert();

            var buddyHelper7 = new BuddyStorageHelper();
            buddyHelper7.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper7.RowKey = TableStorageHelper.ConstructCompleteKey(surfer8.PartitionKey, surfer8.RowKey);
            buddyHelper7.Upsert();

            var buddyHelper8 = new BuddyStorageHelper();
            buddyHelper8.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper8.RowKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper8.Upsert();

            var buddyHelper9 = new BuddyStorageHelper();
            buddyHelper9.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper9.RowKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            buddyHelper9.Upsert();

            var buddyHelper10 = new BuddyStorageHelper();
            buddyHelper10.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper10.RowKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            buddyHelper10.Upsert();

            var buddyHelper11 = new BuddyStorageHelper();
            buddyHelper11.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper11.RowKey = TableStorageHelper.ConstructCompleteKey(surfer4.PartitionKey, surfer4.RowKey);
            buddyHelper11.Upsert();

            var buddyHelper12 = new BuddyStorageHelper();
            buddyHelper12.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper12.RowKey = TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey);
            buddyHelper12.Upsert();

            var buddyHelper13 = new BuddyStorageHelper();
            buddyHelper13.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper13.RowKey = TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey);
            buddyHelper13.Upsert();

            var buddyHelper14 = new BuddyStorageHelper();
            buddyHelper14.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper14.RowKey = TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey);
            buddyHelper14.Upsert();

            var buddyHelper15 = new BuddyStorageHelper();
            buddyHelper15.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            buddyHelper15.RowKey = TableStorageHelper.ConstructCompleteKey(surfer8.PartitionKey, surfer8.RowKey);
            buddyHelper15.Upsert();

            var buddyHelper16 = new BuddyStorageHelper();
            buddyHelper16.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            buddyHelper16.RowKey = TableStorageHelper.ConstructCompleteKey(surfer4.PartitionKey, surfer4.RowKey);
            buddyHelper16.Upsert();

            var buddyHelper17 = new BuddyStorageHelper();
            buddyHelper17.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer4.PartitionKey, surfer4.RowKey);
            buddyHelper17.RowKey = TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey);
            buddyHelper17.Upsert();

            var buddyHelper18 = new BuddyStorageHelper();
            buddyHelper18.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey);
            buddyHelper18.RowKey = TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey);
            buddyHelper18.Upsert();

            var buddyHelper19 = new BuddyStorageHelper();
            buddyHelper19.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey);
            buddyHelper19.RowKey = TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey);
            buddyHelper19.Upsert();

            var buddyHelper20 = new BuddyStorageHelper();
            buddyHelper20.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey);
            buddyHelper20.RowKey = TableStorageHelper.ConstructCompleteKey(surfer8.PartitionKey, surfer8.RowKey);
            buddyHelper20.Upsert();

            var buddyHelper21 = new BuddyStorageHelper();
            buddyHelper21.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer8.PartitionKey, surfer8.RowKey);
            buddyHelper21.RowKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            buddyHelper21.Upsert();

            //BREAKS
            var break1 = new Break("Salt Creek", 33.474336875045324, -117.72346615834977, "USWC");
            break1.RowKey = "bre-111de571-7142-47c8-bdb3-0eddd59f6ccd";

            var break2 = new Break("Lowers", 33.38297036756884, -117.59092211766983, "USWC");
            break2.RowKey = "bre-222de571-7142-47c8-bdb3-0eddd59f6a12";

            var break3 = new Break("Swami's", 33.039442, -117.296847, "USWC");
            break3.RowKey = "bre-10";

            var break4 = new Break("Old Man's", 33.369818, -117.563632, "USWC");
            break4.RowKey = "bre-11";

            var break5 = new Break("Break Ole", 42.992595, -9.276695, "SPAI");
            break5.RowKey = "bre-12";

            var break6 = new Break("Break du France", 48.50745, -4.774983, "FRAN");
            break6.RowKey = "bre-13";

            var break7 = new Break("Surf Noir", 48.503611, -4.779274, "FRAN");
            break7.RowKey = "bre-14";

            var break8 = new Break("2 Francs", 48.498237, -4.780176, "FRAN");
            break8.RowKey = "bre-15";
            
            var breakHelper = new BreakStorageHelper();
            breakHelper.Upsert(break1);
            breakHelper.Upsert(break2);
            breakHelper.Upsert(break3);
            breakHelper.Upsert(break3);
            breakHelper.Upsert(break4);
            breakHelper.Upsert(break5);
            breakHelper.Upsert(break6);
            breakHelper.Upsert(break7);
            breakHelper.Upsert(break8);

            //BREAK.THERENOW 
            var thereNow = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey));
            var thereNow1 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey));
            var thereNow2 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey));
            var thereNow3 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer4.PartitionKey, surfer4.RowKey));
            var thereNow4 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey));
            var thereNow5 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey));
            var thereNow6 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey));
            var thereNow7 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer8.PartitionKey, surfer8.RowKey));
            var thereNow8 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break3.PartitionKey, break3.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey));
            var thereNow9 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break2.PartitionKey, break2.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey));
            var thereNow10 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break2.PartitionKey, break2.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey));
            var thereNow11 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break2.PartitionKey, break2.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey));
            var thereNow12 = new ThereNowStorageHelper(
                TableStorageHelper.ConstructCompleteKey(break2.PartitionKey, break2.RowKey),
                TableStorageHelper.ConstructCompleteKey(surfer8.PartitionKey, surfer8.RowKey));

            thereNow.Upsert();
            thereNow1.Upsert();
            thereNow2.Upsert();
            thereNow3.Upsert();
            thereNow4.Upsert();
            thereNow5.Upsert();
            thereNow6.Upsert();
            thereNow7.Upsert();
            thereNow8.Upsert();
            thereNow9.Upsert();
            thereNow10.Upsert();
            thereNow11.Upsert();
            thereNow12.Upsert();

            //SURFER.BREAKS
            var breakCollectionHelper = new BreakCollectionStorageHelper();
            breakCollectionHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper.RowKey = TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey);
            breakCollectionHelper.Upsert();

            var breakCollectionHelper2 = new BreakCollectionStorageHelper();
            breakCollectionHelper2.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper2.RowKey = TableStorageHelper.ConstructCompleteKey(break2.PartitionKey, break2.RowKey);
            breakCollectionHelper2.Upsert();

            var breakCollectionHelper3 = new BreakCollectionStorageHelper();
            breakCollectionHelper3.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper3.RowKey = TableStorageHelper.ConstructCompleteKey(break3.PartitionKey, break3.RowKey);
            breakCollectionHelper3.Upsert();

            var breakCollectionHelper4 = new BreakCollectionStorageHelper();
            breakCollectionHelper4.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper4.RowKey = TableStorageHelper.ConstructCompleteKey(break4.PartitionKey, break4.RowKey);
            breakCollectionHelper4.Upsert();

            var breakCollectionHelper5 = new BreakCollectionStorageHelper();
            breakCollectionHelper5.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper5.RowKey = TableStorageHelper.ConstructCompleteKey(break5.PartitionKey, break5.RowKey);
            breakCollectionHelper5.Upsert();

            var breakCollectionHelper6 = new BreakCollectionStorageHelper();
            breakCollectionHelper6.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper6.RowKey = TableStorageHelper.ConstructCompleteKey(break6.PartitionKey, break6.RowKey);
            breakCollectionHelper6.Upsert();

            var breakCollectionHelper7 = new BreakCollectionStorageHelper();
            breakCollectionHelper7.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper7.RowKey = TableStorageHelper.ConstructCompleteKey(break7.PartitionKey, break7.RowKey);
            breakCollectionHelper7.Upsert();

            var breakCollectionHelper8 = new BreakCollectionStorageHelper();
            breakCollectionHelper8.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            breakCollectionHelper8.RowKey = TableStorageHelper.ConstructCompleteKey(break8.PartitionKey, break8.RowKey);
            breakCollectionHelper8.Upsert();

            var breakCollectionHelper9 = new BreakCollectionStorageHelper();
            breakCollectionHelper9.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            breakCollectionHelper9.RowKey = TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey);
            breakCollectionHelper9.Upsert();

            var breakCollectionHelper10 = new BreakCollectionStorageHelper();
            breakCollectionHelper10.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            breakCollectionHelper10.RowKey = TableStorageHelper.ConstructCompleteKey(break3.PartitionKey, break3.RowKey);
            breakCollectionHelper10.Upsert();

            var breakCollectionHelper11 = new BreakCollectionStorageHelper();
            breakCollectionHelper11.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            breakCollectionHelper11.RowKey = TableStorageHelper.ConstructCompleteKey(break1.PartitionKey, break1.RowKey);
            breakCollectionHelper11.Upsert();

            var breakCollectionHelper12 = new BreakCollectionStorageHelper();
            breakCollectionHelper12.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            breakCollectionHelper12.RowKey = TableStorageHelper.ConstructCompleteKey(break2.PartitionKey, break2.RowKey);
            breakCollectionHelper12.Upsert();

            //SESSIONS
            var session = new Session(break1, new DateTime(2012, 9, 12, 8, 30, 0), new DateTime(2012, 9, 12, 10, 30, 0));
            session.RowKey = "ses-222de571-7142-47c8-bdb3-0eddd59f6ccd";
            var sessionHelper = new SessionStorageHelper();
            

            var session2 = new Session(break1, new DateTime(2012, 9, 12, 12, 30, 0), new DateTime(2012, 9, 12, 14, 30, 0));
            session2.RowKey = "ses-332de571-7142-47c8-bdb3-0eddd59f6ccd";

            var session3 = new Session(break2, new DateTime(2012, 9, 12, 12, 30, 0), new DateTime(2012, 9, 12, 14, 30, 0));
            session3.RowKey = "ses-442de571-7142-47c8-bdb3-0eddd59f6ccd";

            var session4 = new Session(break3, new DateTime(2012, 9, 12, 12, 30, 0), new DateTime(2012, 9, 12, 14, 30, 0));
            session4.RowKey = "ses-552de571-7142-47c8-bdb3-0eddd59f6ccd";

            var session5 = new Session(break4, new DateTime(2012, 9, 12, 12, 30, 0), new DateTime(2012, 9, 12, 14, 30, 0));
            session5.RowKey = "ses-662de571-7142-47c8-bdb3-0eddd59f6ccd";

            sessionHelper.Upsert(session);
            sessionHelper.Upsert(session2);
            sessionHelper.Upsert(session3);
            sessionHelper.Upsert(session4);
            sessionHelper.Upsert(session5);

            //SESSION.THERENOW - NO LONGER NEEDED - RECIPROCITY BUILT INTO SESSIONCOLLECTIONSTORAGEHELPER.UPSERT if PK = Surfer
            //var thereNowHelper = new ThereNowStorageHelper();
            //thereNowHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(session.PartitionKey, session.RowKey);
            //thereNowHelper.RowKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            //thereNowHelper.Upsert();

            //var thereNowHelper2 = new ThereNowStorageHelper();
            //thereNowHelper2.PartitionKey = TableStorageHelper.ConstructCompleteKey(session.PartitionKey, session.RowKey);
            //thereNowHelper2.RowKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            //thereNowHelper2.Upsert();

            //var thereNowHelper3 = new ThereNowStorageHelper();
            //thereNowHelper3.PartitionKey = TableStorageHelper.ConstructCompleteKey(session.PartitionKey, session.RowKey);
            //thereNowHelper3.RowKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            //thereNowHelper3.Upsert();

            //var thereNowHelper4 = new ThereNowStorageHelper();
            //thereNowHelper4.PartitionKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            //thereNowHelper4.RowKey = TableStorageHelper.ConstructCompleteKey(surfer4.PartitionKey, surfer4.RowKey);
            //thereNowHelper4.Upsert();

            //var thereNowHelper5 = new ThereNowStorageHelper();
            //thereNowHelper5.PartitionKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            //thereNowHelper5.RowKey = TableStorageHelper.ConstructCompleteKey(surfer5.PartitionKey, surfer5.RowKey);
            //thereNowHelper5.Upsert();

            //var thereNowHelper6 = new ThereNowStorageHelper();
            //thereNowHelper6.PartitionKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            //thereNowHelper6.RowKey = TableStorageHelper.ConstructCompleteKey(surfer6.PartitionKey, surfer6.RowKey);
            //thereNowHelper6.Upsert();

            //var thereNowHelper7 = new ThereNowStorageHelper();
            //thereNowHelper7.PartitionKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            //thereNowHelper7.RowKey = TableStorageHelper.ConstructCompleteKey(surfer7.PartitionKey, surfer7.RowKey);
            //thereNowHelper7.Upsert();

            //SURFER.SESSIONS
            var sessionCollectionHelper = new SessionCollectionStorageHelper();
            sessionCollectionHelper.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            sessionCollectionHelper.RowKey = TableStorageHelper.ConstructCompleteKey(session.PartitionKey, session.RowKey);
            sessionCollectionHelper.Upsert();

            var sessionCollectionHelper2 = new SessionCollectionStorageHelper();
            sessionCollectionHelper2.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer.PartitionKey, surfer.RowKey);
            sessionCollectionHelper2.RowKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            sessionCollectionHelper2.Upsert();

            var sessionCollectionHelper3 = new SessionCollectionStorageHelper();
            sessionCollectionHelper3.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            sessionCollectionHelper3.RowKey = TableStorageHelper.ConstructCompleteKey(session.PartitionKey, session.RowKey);
            sessionCollectionHelper3.Upsert();

            var sessionCollectionHelper4 = new SessionCollectionStorageHelper();
            sessionCollectionHelper4.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer2.PartitionKey, surfer2.RowKey);
            sessionCollectionHelper4.RowKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            sessionCollectionHelper4.Upsert();

            var sessionCollectionHelper5 = new SessionCollectionStorageHelper();
            sessionCollectionHelper5.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            sessionCollectionHelper5.RowKey = TableStorageHelper.ConstructCompleteKey(session.PartitionKey, session.RowKey);
            sessionCollectionHelper5.Upsert();

            var sessionCollectionHelper6 = new SessionCollectionStorageHelper();
            sessionCollectionHelper6.PartitionKey = TableStorageHelper.ConstructCompleteKey(surfer3.PartitionKey, surfer3.RowKey);
            sessionCollectionHelper6.RowKey = TableStorageHelper.ConstructCompleteKey(session2.PartitionKey, session2.RowKey);
            sessionCollectionHelper6.Upsert();

            //COMMENTS
            var comment = new Comment("Awesome. This session was the best in a while.", surfer, session); 
            var comment2 = new Comment("Best place when the surf going off!", surfer2, break1);
            var comment3 = new Comment("Cool session. I liked George's ride on the party wave with all the old guys!", surfer3, session);
            var comment4 = new Comment("Don't let it go too long between trips to Salt Creek! I love this break", surfer, break1);
            var comment5 = new Comment("Every time I come here, I wonder if Magic Johnson is watching.", surfer2, break1);
            var comment6 = new Comment("Forget about work when the waves are up here - it's the best.", surfer, break2);
            var comment7 = new Comment("Going here since I was a kid. Still my favorite.", surfer3, break2);
            var comment8 = new Comment("Having this break close by makes living in my little place so worth it.", surfer2, break3);
            var comment9 = new Comment("I come here so often, the dolphins know me.", surfer3, break3); 
            
            var commentHelper = new CommentStorageHelper();
            commentHelper.Upsert(comment);
            commentHelper.Upsert(comment2);
            commentHelper.Upsert(comment3);
            commentHelper.Upsert(comment4);
            commentHelper.Upsert(comment5);
            commentHelper.Upsert(comment6);
            commentHelper.Upsert(comment7);
            commentHelper.Upsert(comment8);
            commentHelper.Upsert(comment9);
        }
    }
}
