﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GoodBreaksClasses;
using GoodBreaksTypes;
using Newtonsoft.Json;
using OAuth2.Mvc;
using System.Web.Http.ValueProviders;
using System.Net.Http.Formatting;

namespace StorageRoleMVC4.Controllers
{
    public class AuthController : ApiController
    {
        //Get a RequestToken
        public string Get()
        {
            OAuthResponse requestToken = new OAuthResponse();
            
            requestToken = OAuthServiceBase.Instance.RequestToken();

            return JsonConvert.SerializeObject(requestToken);
        }

        //Get an AccessToken
        //public string Post(string grant_type, string username, string password, bool? persistent)
        public string Post(string oauth_token, string surferCompleteKey, string password)
        {
            var token = Request.GetToken();
            var response = OAuthServiceBase.Instance.AccessToken(token, "grantType", surferCompleteKey, password, persistent:true);
            return JsonConvert.SerializeObject(response);
        }
        
        //public HttpResponseMessage Post([FromBody] Surfer surfer, [FromUri] string password)
        //{
        //    string hashSalt = string.Empty;
        //    var helper = new SurferStorageHelper();
        //    hashSalt = helper.Save(surfer, password);

        //    var response = Request.CreateResponse(HttpStatusCode.OK, hashSalt);
        //    return response;
        //}
    }

    public static class HttpRequestMessageExtensions
    {
        public static string GetToken(this HttpRequestMessage request)
        {
            if (request == null)
                return String.Empty;

            // Find Header
            var headerText = "";
            if (request.Headers.Authorization != null)
            {
                headerText = request.Headers.GetValues(
                    OAuthConstants.AuthorzationHeader).SingleOrDefault();
            }

            if (!String.IsNullOrEmpty(headerText))
            {
                var header = new AuthorizationHeader(headerText);
                if (string.Equals(header.Scheme, "OAuth", StringComparison.OrdinalIgnoreCase))
                    return header.ParameterText.Trim();
            }

            // Find Clean Param
            var token = request.GetQueryNameValuePairs().SingleOrDefault(
                x => x.Key == OAuthConstants.AuthorzationParam).Value;
            return !String.IsNullOrEmpty(token)
                ? token.Trim()
                : String.Empty;
        }
    }
}
