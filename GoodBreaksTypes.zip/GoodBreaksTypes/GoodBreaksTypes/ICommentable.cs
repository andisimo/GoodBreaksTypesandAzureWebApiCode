﻿using System.Collections.Generic;

namespace GoodBreaksTypes
{
    public interface ICommentable
    {
        SortedCommentList CommentsAboutMe
        { get; set; }

        void AddComment(Comment comment);
    }
}
