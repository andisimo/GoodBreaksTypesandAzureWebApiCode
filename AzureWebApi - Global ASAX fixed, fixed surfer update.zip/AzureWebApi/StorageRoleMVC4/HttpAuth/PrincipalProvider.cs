﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Principal;
using GoodBreaksClasses;

namespace StorageRoleMVC4.HttpAuth
{
    public class PrincipalProvider : IProvidePrincipal
    {
        public IPrincipal CreatePrincipal(string userCompleteKey, string password)
        {
            var securityHelper = new SecurityStorageHelper();
            if (password != securityHelper.Retrieve(userCompleteKey))
            {
                return null;
            }

            var identity = new GenericIdentity(userCompleteKey);
            IPrincipal principal = new GenericPrincipal(identity, new[] { "User" });
            return principal;
        }
    }
}