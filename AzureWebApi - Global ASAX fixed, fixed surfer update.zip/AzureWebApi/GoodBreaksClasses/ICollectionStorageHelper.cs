﻿using System.Collections.Generic;
using System.Collections;
using GoodBreaksTypes;

namespace GoodBreaksClasses
{
    public interface ICollectionStorageHelper
    {
        //methods
        void Upsert();
        void Delete();
    }
}
