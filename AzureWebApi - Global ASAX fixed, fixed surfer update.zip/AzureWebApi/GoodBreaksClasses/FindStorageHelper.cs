﻿using System;
using System.Collections.Generic;
using System.Data.Services.Common;
using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.Data.Services.Client;
using System.Text.RegularExpressions;

namespace GoodBreaksClasses
{
    [DataServiceKey("PartitionKey", "RowKey")]
    public class FindStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SearchTable";
        internal string _searchType;

        //properties
        public string PartitionKey {get; set;}
        public string RowKey { get; set; }
        public string ObjectCompleteKey { get; set; }

        //Constructors
        public FindStorageHelper()
        { }

        public FindStorageHelper(string searchType)
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
            _searchType = searchType;
        }

        //Methods
        public Dictionary<string, string> Retrieve(string searchTerm)
        {
            CloudTableQuery<FindStorageHelper> result =
                (from getThis in _serviceContext.CreateQuery<FindStorageHelper>(_tableName)
                 where getThis.PartitionKey == _searchType
                 select getThis).AsTableServiceQuery<FindStorageHelper>();

            var dictionary = new Dictionary<string, string>();

            foreach (FindStorageHelper searchResult in result)
            {
                if (searchResult.RowKey.ToLower().Contains(searchTerm.ToLower()))
                {
                    dictionary.Add(searchResult.ObjectCompleteKey, searchResult.RowKey);
                }
            }

            return dictionary;
        }


        public void Save(dynamic searchObject)
        {
            if(searchObject.RowKey.ToLower().StartsWith("sur"))
            {
                this.ObjectCompleteKey = TableStorageHelper.ConstructCompleteKey(
                    searchObject.PartitionKey, searchObject.RowKey);
                this.PartitionKey = "Surfer";
                this.RowKey = searchObject.Name;
            }
            else if (searchObject.RowKey.ToLower().StartsWith("bre"))
            {
                this.ObjectCompleteKey = TableStorageHelper.ConstructCompleteKey(
                    searchObject.PartitionKey, searchObject.RowKey);
                this.PartitionKey = "Break";
                this.RowKey = searchObject.Name;
            }

            _serviceContext.AddObject(_tableName, this); 

            _serviceContext.IgnoreMissingProperties = true;

            try
            {
                _serviceContext.SaveChanges();
            }
            catch (DataServiceClientException)
            {
                throw;
            }
            catch (DataServiceRequestException ex2)
            {
                //Since the RowKey for the SearchTable is the Name property, there is
                //a danger of getting DataServiceClientException if 2 users have the same name. 
                //This code block handles that exception and adds an incrementing integer to the
                //end of the name. The search will still work the same, except that if people search
                //for the #1, it could return a lot of results that wouldn't make sense to them. 
                if (ex2.InnerException != null && ex2.InnerException is DataServiceClientException 
                    && ex2.InnerException.Message.ToLower().Contains("the specified entity already exists."))
                {
                    RetrySave();
                }
                else
                {
                    throw;
                }
            }
        }

        private void RetrySave()
        {
            CloudTableQuery<FindStorageHelper> result =
                (from getThis in _serviceContext.CreateQuery<FindStorageHelper>(_tableName)
                 where getThis.PartitionKey == _searchType
                 select getThis).AsTableServiceQuery<FindStorageHelper>();

            var resultList = result.ToList<FindStorageHelper>();
            int finalSuffix = 0;

            foreach (FindStorageHelper searchResult in resultList)
            {
                Regex regex = new Regex(@"[\d]");

                if (searchResult.RowKey.ToLower().StartsWith(this.RowKey.ToLower()) && 
                    regex.IsMatch(searchResult.RowKey[searchResult.RowKey.Length - 1].ToString()))
                {
                    int suffix = Int32.Parse(searchResult.RowKey[searchResult.RowKey.Length - 1].ToString());

                    if (suffix > finalSuffix)
                        finalSuffix = suffix;
                }
            }

            finalSuffix++;
            this.RowKey = this.RowKey + finalSuffix.ToString();

            try
            {
                _serviceContext.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        public void Delete(FindStorageHelper searchItemToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, searchItemToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(searchItemToDelete);
                _serviceContext.AttachTo(_tableName, searchItemToDelete, "*");
            }
            _serviceContext.DeleteObject(searchItemToDelete);
            _serviceContext.SaveChangesWithRetries();
        }
    }
}
