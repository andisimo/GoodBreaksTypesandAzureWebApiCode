﻿using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.Linq;
using System.Xml.Linq;
using GoodBreaksTypes;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GoodBreaksClasses
{
    public class SessionStorageHelper
    {
        //internal fields
        internal CloudStorageAccount _storageAccount;
        public CloudTableClient _tableClient;
        internal TableServiceContext _serviceContext;
        internal string _tableName = "SessionsBreaks";

        //public fields
        public Session sessionInQuestion; 

        //Constructor
        public SessionStorageHelper()
        {
            _storageAccount = CloudStorageAccount.Parse
                (CloudConfigurationManager.GetSetting("StorageConnectionStringCloud"));
            //_storageAccount = CloudStorageAccount.Parse
            //    (CloudConfigurationManager.GetSetting("StorageConnectionStringLocal"));
            _tableClient = _storageAccount.CreateCloudTableClient();
            _serviceContext = _tableClient.GetDataServiceContext();
        }

        //Methods
        public Session Retrieve(string partitionKey, string rowKey)
        {
            Session session;

            try
            {
                session =
                    (from getThis in _serviceContext.CreateQuery<Session>(_tableName)
                     where getThis.PartitionKey == partitionKey &&
                     getThis.RowKey == rowKey
                     select getThis).FirstOrDefault();
            }
            catch (DataServiceQueryException ex1)
            {
                throw ex1;
            }

            return session;
        }

        public void Save(Session session)
        {
            _serviceContext.AddObject(_tableName, session); 

            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Update(Session session)
        {
            _serviceContext.UpdateObject(session);
            _serviceContext.IgnoreMissingProperties = true;
            _serviceContext.SaveChanges();
        }

        public void Upsert(Session sessionToSave)
        {
            //null e-tag = upsert operation
            try
            {
                _serviceContext.AttachTo(_tableName, sessionToSave, null);
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(sessionToSave);
                _serviceContext.AttachTo(_tableName, sessionToSave, null);
            }

            _serviceContext.UpdateObject(sessionToSave);
            //no SaveChangesOption in SaveChanges arguments = merge verb (rather than replace) 
            _serviceContext.SaveChanges();
        }

        public void Delete(Session sessionToDelete)
        {
            try
            {
                _serviceContext.AttachTo(_tableName, sessionToDelete, "*");
            }
            catch (InvalidOperationException)
            {
                _serviceContext.Detach(sessionToDelete);
                _serviceContext.AttachTo(_tableName, sessionToDelete, "*");
            }

            _serviceContext.DeleteObject(sessionToDelete);
            _serviceContext.SaveChanges();

            DeleteAllTraces(sessionToDelete);
        }

        private void DeleteAllTraces(Session deletedSession)
        {
            string sessionCompleteKey = TableStorageHelper.ConstructCompleteKey(
                deletedSession.PartitionKey, deletedSession.RowKey);

            //Delete the CommentsAboutMe references, and the Comments themselves
            var commentHelper = new CommentStorageHelper();

            //CommentsAboutMe
            var commentsAboutMeHelper = new CommentsAboutMeStorageHelper();
            var commentsAboutMeList = commentsAboutMeHelper.RetrieveComments(sessionCompleteKey);

            foreach (Comment c in commentsAboutMeList)
            {
                var commentsAboutMeDeleter = new CommentsAboutMeStorageHelper(sessionCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(c.PartitionKey, c.RowKey));

                commentsAboutMeDeleter.Delete();
                commentHelper.Delete(c);
            }

            //Delete the ThereNow partition for this Session (has all surfers who attended session in past)
            var thereNowHelper = new ThereNowStorageHelper();
            var surferList = thereNowHelper.RetrieveSurfersThereNow(sessionCompleteKey);

            foreach (Surfer s in surferList)
            {
                var thereNowDeleter = new ThereNowStorageHelper(sessionCompleteKey,
                    TableStorageHelper.ConstructCompleteKey(s.PartitionKey, s.RowKey));

                thereNowDeleter.Delete();
            }

            //Delete the Rows in SessionsCollection
            //Put something in a Queue for an Azure worker role to delete these rows
        }
    }
}
